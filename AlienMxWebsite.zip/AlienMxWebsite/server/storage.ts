import { 
  users, categories, products, memberships, articles, forumPosts, sightings,
  type User, type InsertUser, 
  type Product, type InsertProduct,
  type Membership, type InsertMembership,
  type Article, type InsertArticle,
  type ForumPost, type InsertForumPost,
  type Sighting, type InsertSighting
} from "@shared/schema";

// Interface with CRUD methods for all entity types
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;

  // Products
  getProduct(id: number): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Memberships
  getMembership(id: number): Promise<Membership | undefined>;
  getMemberships(): Promise<Membership[]>;
  createMembership(membership: InsertMembership): Promise<Membership>;

  // Articles
  getArticle(id: number): Promise<Article | undefined>;
  getArticles(): Promise<Article[]>;
  createArticle(article: InsertArticle): Promise<Article>;

  // Forum Posts
  getForumPost(id: number): Promise<ForumPost | undefined>;
  getForumPosts(): Promise<ForumPost[]>;
  createForumPost(post: InsertForumPost): Promise<ForumPost>;

  // Sightings
  getSighting(id: number): Promise<Sighting | undefined>;
  getSightings(): Promise<Sighting[]>;
  createSighting(sighting: InsertSighting): Promise<Sighting>;

  // Categories
  getCategory(id: number): Promise<any | undefined>;
  getCategories(): Promise<any[]>;
  createCategory(category: any): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private memberships: Map<number, Membership>;
  private articles: Map<number, Article>;
  private forumPosts: Map<number, ForumPost>;
  private sightings: Map<number, Sighting>;
  private categories: Map<number, any>;
  
  private userId: number;
  private productId: number;
  private membershipId: number;
  private articleId: number;
  private forumPostId: number;
  private sightingId: number;
  private categoryId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.memberships = new Map();
    this.articles = new Map();
    this.forumPosts = new Map();
    this.sightings = new Map();
    this.categories = new Map();
    
    this.userId = 1;
    this.productId = 1;
    this.membershipId = 1;
    this.articleId = 1;
    this.forumPostId = 1;
    this.sightingId = 1;
    this.categoryId = 1;

    // Initialize with sample categories
    this.initializeCategories();
  }

  private initializeCategories() {
    const sampleCategories = [
      { id: this.categoryId++, name: 'Telescopios', slug: 'telescopios', description: 'Equipos de observación astronómica' },
      { id: this.categoryId++, name: 'Ropa', slug: 'ropa', description: 'Camisetas y vestimenta temática' },
      { id: this.categoryId++, name: 'Modelos', slug: 'modelos', description: 'Modelos a escala de OVNIs y naves' },
      { id: this.categoryId++, name: 'Libros', slug: 'libros', description: 'Libros y publicaciones sobre fenómenos extraterrestres' },
      { id: this.categoryId++, name: 'Investigación', slug: 'investigacion', description: 'Artículos de investigación' },
      { id: this.categoryId++, name: 'Historia', slug: 'historia', description: 'Artículos históricos' },
      { id: this.categoryId++, name: 'Revelaciones', slug: 'revelaciones', description: 'Revelaciones y desclasificaciones' }
    ];

    sampleCategories.forEach(category => {
      this.categories.set(category.id, category);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      level: 1, 
      points: 0, 
      role: 'user',
      createdAt: now,
      avatar: insertUser.avatar || null
    };
    this.users.set(id, user);
    return user;
  }

  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const now = new Date();
    const product: Product = { 
      ...insertProduct, 
      id,
      createdAt: now,
      originalPrice: insertProduct.originalPrice || null,
      images: insertProduct.images || null,
      categoryId: insertProduct.categoryId || null,
      stock: insertProduct.stock || 0,
      rating: insertProduct.rating || 0,
      reviews: insertProduct.reviews || 0,
      isNew: insertProduct.isNew || false,
      isPopular: insertProduct.isPopular || false,
      isLimitedStock: insertProduct.isLimitedStock || false
    };
    this.products.set(id, product);
    return product;
  }

  // Membership methods
  async getMembership(id: number): Promise<Membership | undefined> {
    return this.memberships.get(id);
  }

  async getMemberships(): Promise<Membership[]> {
    return Array.from(this.memberships.values());
  }

  async createMembership(insertMembership: InsertMembership): Promise<Membership> {
    const id = this.membershipId++;
    const membership: Membership = { 
      ...insertMembership, 
      id,
      isPopular: insertMembership.isPopular || false
    };
    this.memberships.set(id, membership);
    return membership;
  }

  // Article methods
  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async getArticles(): Promise<Article[]> {
    return Array.from(this.articles.values());
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.articleId++;
    const now = new Date();
    const article: Article = { 
      ...insertArticle, 
      id,
      views: 0,
      comments: 0,
      createdAt: now,
      categoryId: insertArticle.categoryId || null,
      image: insertArticle.image || null,
      authorId: insertArticle.authorId || null
    };
    this.articles.set(id, article);
    return article;
  }

  // Forum Post methods
  async getForumPost(id: number): Promise<ForumPost | undefined> {
    return this.forumPosts.get(id);
  }

  async getForumPosts(): Promise<ForumPost[]> {
    return Array.from(this.forumPosts.values());
  }

  async createForumPost(insertForumPost: InsertForumPost): Promise<ForumPost> {
    const id = this.forumPostId++;
    const now = new Date();
    const forumPost: ForumPost = { 
      ...insertForumPost, 
      id,
      views: 0,
      comments: 0,
      createdAt: now,
      categoryId: insertForumPost.categoryId || null
    };
    this.forumPosts.set(id, forumPost);
    return forumPost;
  }

  // Sighting methods
  async getSighting(id: number): Promise<Sighting | undefined> {
    return this.sightings.get(id);
  }

  async getSightings(): Promise<Sighting[]> {
    return Array.from(this.sightings.values());
  }

  async createSighting(insertSighting: InsertSighting): Promise<Sighting> {
    const id = this.sightingId++;
    const now = new Date();
    const sighting: Sighting = { 
      ...insertSighting, 
      id,
      createdAt: now,
      images: insertSighting.images || null,
      reporterId: insertSighting.reporterId || null,
      witnesses: insertSighting.witnesses || null,
      verifiedBy: insertSighting.verifiedBy || null
    };
    this.sightings.set(id, sighting);
    return sighting;
  }

  // Category methods
  async getCategory(id: number): Promise<any | undefined> {
    return this.categories.get(id);
  }

  async getCategories(): Promise<any[]> {
    return Array.from(this.categories.values());
  }

  async createCategory(category: any): Promise<any> {
    const id = this.categoryId++;
    const newCategory = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
}

export const storage = new MemStorage();
