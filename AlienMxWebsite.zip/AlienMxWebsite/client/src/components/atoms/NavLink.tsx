import React from 'react';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
  isActive?: boolean;
}

export const NavLink: React.FC<NavLinkProps> = ({
  href,
  children,
  className,
  isActive,
}) => {
  return (
    <Link href={href} 
      className={cn(
        'nav-link font-medium relative transition',
        isActive ? 'text-alien-teal' : 'hover:text-alien-teal',
        className
      )}>
      {children}
    </Link>
  );
};
