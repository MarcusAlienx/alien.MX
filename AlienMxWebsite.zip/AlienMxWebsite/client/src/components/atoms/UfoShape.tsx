import React, { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface UfoShapeProps {
  children?: ReactNode;
  className?: string;
  variant?: 'green' | 'teal' | 'default';
  glow?: boolean;
}

const variantStyles = {
  green: 'bg-alien-green/20 backdrop-blur-md shadow-neon-green',
  teal: 'bg-alien-teal/20 backdrop-blur-md shadow-neon-teal',
  default: 'bg-gradient-to-br from-alien-green to-alien-teal'
};

export const UfoShape: React.FC<UfoShapeProps> = ({
  children,
  className,
  variant = 'default',
  glow = false
}) => {
  return (
    <div className={cn(
      'ufo-shape rounded-full flex items-center justify-center',
      variantStyles[variant],
      glow && 'shadow-lg',
      className
    )}>
      {children}
    </div>
  );
};
