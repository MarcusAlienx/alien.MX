import React, { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface GradientTextProps {
  children: ReactNode;
  className?: string;
}

export const GradientText: React.FC<GradientTextProps> = ({ children, className }) => {
  return (
    <span className={cn('gradient-text', className)}>
      {children}
    </span>
  );
};
