import React from 'react';
import { cn } from '@/lib/utils';

interface MapMarkerProps {
  type: 'recent' | 'verified' | 'investigation';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
}

const typeStyles = {
  recent: 'bg-alien-green',
  verified: 'bg-alien-teal',
  investigation: 'bg-yellow-400'
};

const sizeStyles = {
  sm: 'w-4 h-4',
  md: 'w-6 h-6',
  lg: 'w-8 h-8'
};

export const MapMarker: React.FC<MapMarkerProps> = ({
  type,
  size = 'md',
  className,
  onClick
}) => {
  return (
    <div 
      className={cn('map-marker', className)}
      onClick={onClick}
    >
      <div className={cn(
        'rounded-full flex items-center justify-center',
        typeStyles[type],
        sizeStyles[size]
      )}>
        <span className={cn(
          "material-icons text-alien-dark",
          size === 'sm' && 'text-xs',
          size === 'md' && 'text-sm'
        )}>
          location_on
        </span>
      </div>
    </div>
  );
};
