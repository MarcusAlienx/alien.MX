import React from 'react';
import { BadgeVariant } from '@/types';
import { cn } from '@/lib/utils';

interface BadgeProps {
  variant: BadgeVariant;
  children: React.ReactNode;
  className?: string;
}

const badgeStyles: Record<BadgeVariant, string> = {
  new: 'bg-alien-green text-alien-dark',
  popular: 'bg-purple-500 text-white',
  limited: 'bg-red-500 text-white',
  sale: 'bg-amber-500 text-alien-dark',
  info: 'bg-alien-teal/20 text-alien-teal',
  event: 'bg-yellow-400/30 text-yellow-400',
  analysis: 'bg-alien-purple/30 text-alien-teal',
  sighting: 'bg-alien-green/30 text-alien-green',
};

export const Badge: React.FC<BadgeProps> = ({ variant, children, className }) => {
  return (
    <span 
      className={cn(
        'font-bold text-xs px-2 py-1 rounded',
        badgeStyles[variant],
        className
      )}
    >
      {children}
    </span>
  );
};
