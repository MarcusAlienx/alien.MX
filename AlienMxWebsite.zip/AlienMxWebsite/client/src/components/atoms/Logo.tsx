import React from 'react';
import { cn } from '@/lib/utils';
import { Link } from 'wouter';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showText?: boolean;
}

const sizeClasses = {
  sm: {
    logo: 'h-8',
  },
  md: {
    logo: 'h-10 lg:h-12',
  },
  lg: {
    logo: 'h-16',
  }
};

export const Logo: React.FC<LogoProps> = ({ size = 'md', className, showText = true }) => {
  const { logo } = sizeClasses[size];
  
  return (
    <Link href="/">
      <div className={cn('flex items-center cursor-pointer', className)}>
        {showText ? (
          <img 
            src="/images/logo-large.png" 
            alt="Alien.mx Logo" 
            className={cn('object-contain animate-float', logo)}
          />
        ) : (
          <img 
            src="/images/logo-small.png" 
            alt="Alien.mx Logo" 
            className={cn('object-contain animate-float', logo)}
          />
        )}
      </div>
    </Link>
  );
};
