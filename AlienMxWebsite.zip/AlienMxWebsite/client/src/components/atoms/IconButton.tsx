import React from 'react';
import { cn } from '@/lib/utils';

interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode;
  variant?: 'default' | 'green' | 'teal' | 'transparent';
  size?: 'sm' | 'md' | 'lg';
  badge?: number;
  className?: string;
}

const variantStyles = {
  default: 'text-white hover:text-white',
  green: 'text-alien-green hover:text-white',
  teal: 'text-alien-teal hover:text-white',
  transparent: 'bg-alien-darker/80 border border-gray-700 text-alien-teal hover:border-alien-teal'
};

const sizeStyles = {
  sm: 'w-6 h-6',
  md: 'w-10 h-10',
  lg: 'w-12 h-12'
};

export const IconButton: React.FC<IconButtonProps> = ({
  icon,
  variant = 'default',
  size = 'md',
  badge,
  className,
  ...props
}) => {
  return (
    <button
      className={cn(
        'relative rounded-full flex items-center justify-center transition',
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
      {...props}
    >
      {icon}
      {typeof badge === 'number' && (
        <span className="absolute -top-1 -right-1 bg-alien-teal text-alien-dark font-bold rounded-full h-5 w-5 flex items-center justify-center text-xs">
          {badge}
        </span>
      )}
    </button>
  );
};
