import React from 'react';
import { cn } from '@/lib/utils';
import { ButtonVariant, ButtonSize } from '@/types';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  children: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary: 'bg-gradient-to-r from-alien-green to-alien-teal text-alien-dark font-space font-bold hover:shadow-neon-green',
  secondary: 'border border-alien-teal text-alien-teal font-space font-bold hover:bg-alien-teal/10 hover:shadow-neon-teal',
  tertiary: 'border border-gray-600 text-gray-300 hover:border-gray-400',
  icon: 'bg-alien-dark rounded-full flex items-center justify-center border border-alien-teal hover:bg-alien-teal hover:text-alien-dark'
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-4 py-2 text-sm rounded-lg',
  md: 'px-6 py-3 rounded-lg',
  lg: 'px-8 py-4 rounded-lg'
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  icon,
  className,
  fullWidth,
  ...props
}) => {
  return (
    <button
      className={cn(
        'transition hover-grow',
        variantStyles[variant],
        sizeStyles[size],
        fullWidth ? 'w-full' : '',
        className
      )}
      {...props}
    >
      <div className="flex items-center justify-center">
        {icon && <span className="mr-2">{icon}</span>}
        {children}
      </div>
    </button>
  );
};
