import React, { useState, useEffect } from 'react';
import { motion, Variants, AnimatePresence } from 'framer-motion';
import { useCartStore } from '@/lib/store';

interface FloatingCartIconProps {
  productId: number;
  sourcePosition: { x: number; y: number };
  onAnimationComplete: () => void;
}

// Variantes para la animación del icono flotante
const iconVariants: Variants = {
  start: ({ x, y }: { x: number; y: number }) => ({
    opacity: 1,
    scale: 0.5,
    x,
    y,
  }),
  end: {
    opacity: [1, 1, 0],
    scale: [0.5, 1.2, 0.8],
    x: window.innerWidth - 70, // Posición aproximada del icono del carrito en el header
    y: 20,
    transition: {
      duration: 0.8,
      ease: 'easeInOut',
      times: [0, 0.8, 1]
    }
  }
};

export const FloatingCartIcon: React.FC<FloatingCartIconProps> = ({ 
  productId,
  sourcePosition,
  onAnimationComplete
}) => {
  // Usamos un estado local para controlar cuándo mostrar el icono
  const [isVisible, setIsVisible] = useState(true);

  // Efecto para ocultar el icono después de la animación
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      onAnimationComplete();
    }, 1000); // Duración total de la animación + margen

    return () => clearTimeout(timer);
  }, [onAnimationComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed z-[9999] pointer-events-none"
          custom={sourcePosition}
          variants={iconVariants}
          initial="start"
          animate="end"
        >
          <div className="relative">
            <span className="material-icons text-alien-teal text-3xl filter drop-shadow-glow">
              shopping_cart
            </span>
            <motion.div
              className="absolute -top-1 -right-1 bg-alien-green text-xs text-gray-900 rounded-full w-4 h-4 flex items-center justify-center font-bold"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2 }}
            >
              1
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FloatingCartIcon;