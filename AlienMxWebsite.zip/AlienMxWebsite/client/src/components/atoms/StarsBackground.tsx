import React from 'react';
import { cn } from '@/lib/utils';

interface StarsBackgroundProps {
  className?: string;
}

export const StarsBackground: React.FC<StarsBackgroundProps> = ({ className }) => {
  return (
    <div 
      className={cn(
        'absolute inset-0 bg-star-field bg-alien-darker z-0',
        className
      )}
    >
      <div className="absolute inset-0 bg-gradient-radial from-alien-purple/30 to-alien-darker"></div>
    </div>
  );
};
