import React from 'react';
import { cn } from '@/lib/utils';

interface RatingProps {
  value: number;
  reviewCount?: number;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const sizeClasses = {
  sm: 'text-xs',
  md: 'text-sm',
  lg: 'text-base'
};

export const Rating: React.FC<RatingProps> = ({
  value,
  reviewCount,
  className,
  size = 'sm'
}) => {
  const fullStars = Math.floor(value);
  const hasHalfStar = value - fullStars >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return (
    <div className={cn('flex items-center', className)}>
      <div className="flex">
        {[...Array(fullStars)].map((_, i) => (
          <span key={`full-${i}`} className={cn("material-icons text-yellow-400", sizeClasses[size])}>star</span>
        ))}
        
        {hasHalfStar && (
          <span className={cn("material-icons text-yellow-400", sizeClasses[size])}>star_half</span>
        )}
        
        {[...Array(emptyStars)].map((_, i) => (
          <span key={`empty-${i}`} className={cn("material-icons text-gray-500", sizeClasses[size])}>star</span>
        ))}
      </div>
      
      {reviewCount !== undefined && (
        <span className={cn("ml-1 text-gray-400", sizeClasses[size])}>({reviewCount})</span>
      )}
    </div>
  );
};
