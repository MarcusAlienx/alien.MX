import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/atoms/Button';
import { Product } from '@/types';
import { useCartStore } from '@/lib/store';

interface AddToCartButtonProps {
  product: Product;
  quantity?: number;
  className?: string;
  fullWidth?: boolean;
  showQuantity?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary' | 'tertiary';
}

export const AddToCartButton: React.FC<AddToCartButtonProps> = ({
  product,
  quantity = 1,
  className,
  fullWidth = false,
  showQuantity = true,
  size = 'md',
  variant = 'primary'
}) => {
  const { addItem, openCart } = useCartStore();
  const [itemQuantity, setItemQuantity] = useState(quantity);
  const [isAdding, setIsAdding] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Animación del ícono flotante
  const floatingIcon = {
    hidden: { opacity: 0, y: 0, scale: 0.5 },
    visible: { 
      opacity: [0, 1, 1, 0], 
      y: -60,
      scale: [0.5, 1.2, 1.2, 0.8],
      transition: { duration: 1, times: [0, 0.2, 0.8, 1] }
    }
  };

  // Animación de éxito
  const successVariants = {
    hidden: { opacity: 0, scale: 0.5 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { type: 'spring', stiffness: 300, damping: 15 }
    },
    exit: { 
      opacity: 0, 
      scale: 0.5,
      transition: { duration: 0.2 }
    }
  };

  const handleIncrement = () => {
    setItemQuantity(prev => prev + 1);
  };

  const handleDecrement = () => {
    if (itemQuantity > 1) {
      setItemQuantity(prev => prev - 1);
    }
  };

  const handleAddToCart = () => {
    setIsAdding(true);
    
    // Añadir producto después de un breve retraso para permitir la animación
    setTimeout(() => {
      addItem(product, itemQuantity);
      setShowSuccess(true);
      
      // Ocultar mensaje de éxito después de un tiempo
      setTimeout(() => {
        setShowSuccess(false);
        setIsAdding(false);
      }, 2000);
    }, 500);
  };

  const handleViewCart = () => {
    openCart();
  };

  return (
    <div className={cn('relative', className)}>
      {/* Icono flotante cuando se añade al carrito */}
      <AnimatePresence>
        {isAdding && (
          <motion.div
            className="absolute w-10 h-10 -top-2 left-1/2 transform -translate-x-1/2 flex items-center justify-center z-10 text-alien-teal"
            variants={floatingIcon}
            initial="hidden"
            animate="visible"
            exit="hidden"
          >
            <span className="material-icons text-2xl">shopping_cart</span>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Mensaje de éxito */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            className="absolute w-full -top-12 left-0 p-2 bg-alien-green/20 text-alien-green rounded-lg text-center font-medium text-sm"
            variants={successVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            ¡Producto añadido!
            <motion.span 
              className="block text-xs underline cursor-pointer mt-1"
              whileHover={{ scale: 1.05 }}
              onClick={handleViewCart}
            >
              Ver carrito
            </motion.span>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="flex items-center">
        {/* Selector de cantidad */}
        {showQuantity && (
          <div className="flex items-center mr-2 bg-gray-800 rounded-full h-8 p-1">
            <motion.button 
              className="w-6 h-6 rounded-full flex items-center justify-center text-sm bg-alien-blue/25 text-gray-200"
              whileHover={{ scale: 1.1, backgroundColor: "rgba(76, 201, 240, 0.5)" }}
              whileTap={{ scale: 0.9 }}
              onClick={handleDecrement}
              disabled={isAdding}
            >
              -
            </motion.button>
            <motion.span 
              className="mx-3 text-sm font-medium"
              key={itemQuantity}
              initial={{ scale: 1 }}
              animate={{ 
                scale: itemQuantity > 1 ? [1, 1.2, 1] : 1,
                transition: { duration: 0.2 }
              }}
            >
              {itemQuantity}
            </motion.span>
            <motion.button 
              className="w-6 h-6 rounded-full flex items-center justify-center text-sm bg-alien-teal/30 text-white"
              whileHover={{ scale: 1.1, backgroundColor: "rgba(76, 201, 240, 0.7)" }}
              whileTap={{ scale: 0.9 }}
              onClick={handleIncrement}
              disabled={isAdding}
            >
              +
            </motion.button>
          </div>
        )}
        
        <motion.div
          whileHover={{ scale: isAdding ? 1 : 1.02 }}
          whileTap={{ scale: isAdding ? 1 : 0.98 }}
          style={{ width: fullWidth ? '100%' : 'auto' }}
        >
          <Button
            variant={variant}
            onClick={handleAddToCart}
            disabled={isAdding}
            fullWidth={fullWidth}
            size={size}
            className={cn(
              isAdding && 'opacity-80 cursor-not-allowed',
            )}
            icon={<span className="material-icons mr-2">add_shopping_cart</span>}
          >
            {isAdding ? 'Añadiendo...' : 'Añadir al carrito'}
          </Button>
        </motion.div>
      </div>
    </div>
  );
};