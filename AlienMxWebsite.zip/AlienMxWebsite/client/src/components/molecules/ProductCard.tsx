import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/atoms/Badge';
import { Rating } from '@/components/atoms/Rating';
import { IconButton } from '@/components/atoms/IconButton';
import { AddToCartButton } from '@/components/molecules/AddToCartButton';
import { motion } from 'framer-motion';
import { Product } from '@/types';
import { useCartStore } from '@/lib/store';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, className }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div 
      className={cn(
        'product-card relative bg-alien-blue rounded-xl overflow-hidden border border-gray-700 hover:border-alien-teal/50 transition-colors duration-300',
        className
      )}
      whileHover={{ 
        y: -5,
        boxShadow: '0 10px 25px rgba(0, 255, 180, 0.1)',
        transition: { duration: 0.3 }
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <div className="aspect-square overflow-hidden relative">
        <motion.img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover"
          animate={{ scale: isHovered ? 1.05 : 1 }}
          transition={{ duration: 0.5 }}
        />
        {product.badge && (
          <Badge
            variant={product.badge}
            className="absolute top-3 left-3"
          >
            {product.badge === 'new' && 'NUEVO'}
            {product.badge === 'popular' && 'POPULAR'}
            {product.badge === 'limited' && 'ÚLTIMAS UNIDADES'}
            {product.badge === 'sale' && 'OFERTA'}
          </Badge>
        )}
        
        {/* Quick add to cart button - appears on hover */}
        <motion.div 
          className="absolute bottom-0 left-0 right-0 bg-black/70 backdrop-blur-sm p-2 flex justify-center items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 20 }}
          transition={{ duration: 0.3 }}
        >
          <AddToCartButton 
            product={product} 
            variant="primary"
            size="sm"
            showQuantity={false}
          />
        </motion.div>
      </div>
      
      <div className="p-4">
        <h3 className="font-space font-medium text-lg mb-1 line-clamp-1">
          {product.name}
        </h3>
        
        <Rating 
          value={product.rating} 
          reviewCount={product.reviews} 
          className="mb-2" 
        />
        
        <div className="flex justify-between items-center">
          <div>
            {product.originalPrice && (
              <span className="text-gray-400 text-sm line-through">
                ${product.originalPrice.toLocaleString()}
              </span>
            )}
            <motion.div 
              className="font-space font-bold text-xl text-white"
              animate={{ 
                scale: product.originalPrice ? [1, 1.1, 1] : 1,
              }}
              transition={{ 
                duration: 0.5, 
                repeat: product.originalPrice ? 2 : 0, 
                repeatType: "reverse",
                repeatDelay: 4
              }}
            >
              ${product.price.toLocaleString()}
            </motion.div>
          </div>
          
          <motion.div
            whileHover={{ scale: 1.1, rotate: 10 }}
            whileTap={{ scale: 0.9 }}
          >
            <IconButton
              icon={<span className="material-icons">shopping_cart</span>}
              variant="green"
              onClick={() => {
                // No necesitamos manejar esto aquí ya que el AddToCartButton se encarga de ello
              }}
              badge={product.isNew || product.isPopular ? 1 : undefined}
            />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};
