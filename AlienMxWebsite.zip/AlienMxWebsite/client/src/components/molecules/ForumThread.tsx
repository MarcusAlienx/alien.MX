import React from 'react';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/atoms/Avatar';
import { Badge } from '@/components/atoms/Badge';
import { ForumPost } from '@/types';

interface ForumThreadProps {
  post: ForumPost;
  className?: string;
}

export const ForumThread: React.FC<ForumThreadProps> = ({ post, className }) => {
  return (
    <div className={cn(
      'p-4 hover:bg-alien-blue/60 transition duration-200',
      className
    )}>
      <div className="flex items-start">
        <Avatar 
          src={post.author.avatar || ''} 
          alt={`Avatar de ${post.author.username}`} 
          className="mr-3" 
        />
        <div className="flex-grow">
          <h4 className="font-medium mb-1">{post.title}</h4>
          <p className="text-sm text-gray-400 line-clamp-2">{post.content}</p>
          <div className="flex items-center mt-2 text-xs text-gray-500">
            <span>Por <span className={`text-${post.author.level && post.author.level > 30 ? 'alien-teal' : 'alien-green'}`}>{post.author.username}</span></span>
            <span className="mx-2">•</span>
            <span>{post.timestamp}</span>
            <span className="mx-2">•</span>
            <div className="flex items-center">
              <span className="material-icons text-xs mr-1">forum</span>
              <span>{post.comments}</span>
            </div>
          </div>
        </div>
        <Badge 
          variant={
            post.category === 'Análisis' ? 'analysis' :
            post.category === 'Avistamiento' ? 'sighting' :
            post.category === 'Evento' ? 'event' : 'info'
          }
          className="ml-2 flex-shrink-0"
        >
          {post.category}
        </Badge>
      </div>
    </div>
  );
};
