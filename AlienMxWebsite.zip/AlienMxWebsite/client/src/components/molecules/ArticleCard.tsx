import React from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/atoms/Badge';
import { Avatar } from '@/components/atoms/Avatar';
import { Article } from '@/types';

interface ArticleCardProps {
  article: Article;
  className?: string;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({ article, className }) => {
  return (
    <div className={cn(
      'article-card bg-alien-blue rounded-xl overflow-hidden border border-gray-700 hover:border-alien-teal/50 transition duration-300 hover-grow',
      className
    )}>
      <div className="h-48 overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-5">
        <div className="flex items-center mb-3">
          <Badge 
            variant={
              article.category === 'Investigación' ? 'analysis' :
              article.category === 'Historia' ? 'sighting' :
              article.category === 'Revelaciones' ? 'event' : 'info'
            }
          >
            {article.category}
          </Badge>
          <span className="text-xs text-gray-400 ml-auto">{article.date}</span>
        </div>
        <h3 className="font-space font-medium text-lg mb-2">{article.title}</h3>
        <p className="text-sm text-gray-400 mb-4 line-clamp-3">{article.excerpt}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Avatar src={article.author.avatar || ''} alt={article.author.username} size="xs" className="mr-2" />
            <span className="text-xs text-gray-400">Por <span className="text-white">{article.author.username}</span></span>
          </div>
          <div className="flex items-center text-xs text-gray-500">
            <span className="material-icons text-xs mr-1">visibility</span>
            <span>{article.views >= 1000 ? `${(article.views / 1000).toFixed(1)}k` : article.views}</span>
            <span className="material-icons text-xs ml-3 mr-1">forum</span>
            <span>{article.comments}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
