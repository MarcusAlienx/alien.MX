import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { CartItem as CartItemType } from '@/types';
import { useCartStore } from '@/lib/store';
import { motion } from 'framer-motion';

interface CartItemProps {
  item: CartItemType;
  className?: string;
}

export const CartItem: React.FC<CartItemProps> = ({ item, className }) => {
  const { updateQuantity, removeItem } = useCartStore();
  const { product, quantity } = item;
  const [isRemoving, setIsRemoving] = useState(false);

  const handleIncrement = () => {
    updateQuantity(product.id, quantity + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      updateQuantity(product.id, quantity - 1);
    } else {
      // Si la cantidad llega a 1 y se pulsa decrementar, eliminamos el producto
      handleRemove();
    }
  };

  const handleRemove = () => {
    setIsRemoving(true);
    // Dejamos tiempo para que la animación ocurra antes de eliminar el producto
    setTimeout(() => {
      removeItem(product.id);
    }, 300);
  };

  const itemTotal = product.price * quantity;

  return (
    <motion.div 
      className={cn('py-4 flex', className)}
      layout
      animate={isRemoving ? { 
        opacity: 0, 
        x: -100,
        transition: { duration: 0.3 }
      } : {}}
    >
      <motion.div 
        className="w-20 h-20 rounded-md overflow-hidden"
        whileHover={{ scale: 1.05 }}
      >
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover"
        />
      </motion.div>
      <div className="ml-4 flex-grow">
        <motion.h4 
          className="font-medium truncate"
          whileHover={{ scale: 1.01 }}
        >
          {product.name}
        </motion.h4>
        <div className="flex justify-between items-center mt-1">
          <motion.div 
            className="text-sm text-gray-400"
            key={quantity} // Para animar cuando cambia la cantidad
            initial={{ opacity: 0.7 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            {quantity} x ${product.price.toLocaleString()}
          </motion.div>
          <motion.div 
            className="text-sm text-alien-teal font-medium"
            key={itemTotal} // Para animar cuando cambia el total
            initial={{ scale: 1 }}
            animate={{ 
              scale: [1, 1.1, 1],
              transition: { duration: 0.3 }
            }}
          >
            ${itemTotal.toLocaleString()}
          </motion.div>
        </div>
        <div className="flex items-center mt-2">
          <div className="flex items-center bg-gray-800 rounded-full h-8 p-1">
            <motion.button 
              className="w-6 h-6 rounded-full flex items-center justify-center text-sm bg-alien-blue/25 text-gray-200"
              whileHover={{ scale: 1.1, backgroundColor: "rgba(76, 201, 240, 0.5)" }}
              whileTap={{ scale: 0.9 }}
              onClick={handleDecrement}
            >
              -
            </motion.button>
            <motion.span 
              className="mx-3 text-sm font-medium"
              key={quantity}
              initial={{ scale: 1 }}
              animate={{ 
                scale: [1, 1.2, 1],
                transition: { duration: 0.2 }
              }}
            >
              {quantity}
            </motion.span>
            <motion.button 
              className="w-6 h-6 rounded-full flex items-center justify-center text-sm bg-alien-teal/30 text-white"
              whileHover={{ scale: 1.1, backgroundColor: "rgba(76, 201, 240, 0.7)" }}
              whileTap={{ scale: 0.9 }}
              onClick={handleIncrement}
            >
              +
            </motion.button>
          </div>
          <motion.button 
            className="ml-auto text-red-400 hover:text-red-300 text-sm flex items-center"
            whileHover={{ scale: 1.05, color: "#FF4747" }}
            whileTap={{ scale: 0.95 }}
            onClick={handleRemove}
          >
            <span className="material-icons text-sm mr-1">delete</span>
            Eliminar
          </motion.button>
        </div>

        {/* Badges para productos especiales */}
        {(product.isNew || product.isPopular || product.isLimitedStock) && (
          <div className="flex space-x-2 mt-2">
            {product.isNew && (
              <motion.span
                className="text-xs bg-alien-green/20 text-alien-green px-2 py-0.5 rounded-full"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                Nuevo
              </motion.span>
            )}
            {product.isPopular && (
              <motion.span
                className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded-full"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                Popular
              </motion.span>
            )}
            {product.isLimitedStock && (
              <motion.span
                className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Stock Limitado
              </motion.span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};
