import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/atoms/Button';

interface NewsletterProps {
  className?: string;
}

export const Newsletter: React.FC<NewsletterProps> = ({ className }) => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setIsSubmitting(true);
    
    // Mock API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setEmail('');
      
      setTimeout(() => {
        setIsSuccess(false);
      }, 3000);
    }, 1000);
  };

  return (
    <form 
      className={cn('flex flex-col sm:flex-row gap-4', className)}
      onSubmit={handleSubmit}
    >
      <input 
        type="email" 
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Tu correo electrónico" 
        className="flex-grow px-5 py-4 bg-alien-dark border border-gray-700 rounded-lg focus:border-alien-teal focus:outline-none focus:ring-1 focus:ring-alien-teal placeholder-gray-500"
        required
      />
      <Button 
        type="submit"
        size="lg"
        disabled={isSubmitting || isSuccess}
      >
        {isSubmitting ? 'ENVIANDO...' : isSuccess ? '¡SUSCRITO!' : 'SUSCRIBIRSE'}
      </Button>
    </form>
  );
};
