import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/atoms/Button';
import { Event } from '@/types';

interface EventCardProps {
  event: Event;
  className?: string;
}

export const EventCard: React.FC<EventCardProps> = ({ event, className }) => {
  return (
    <div className={cn('p-4', className)}>
      <div className="font-medium mb-1">{event.title}</div>
      <div className="text-sm text-gray-400 mb-2">{event.description}</div>
      <div className="flex justify-between items-center">
        <div className="flex items-center text-xs text-gray-500">
          <span className="material-icons text-xs mr-1">calendar_today</span>
          <span>{event.date}</span>
        </div>
        <Button 
          size="sm" 
          className={cn(
            'text-xs py-1 px-2 rounded-full',
            event.buttonVariant === 'reminder' 
              ? 'bg-alien-teal/20 text-alien-teal hover:bg-alien-teal/30' 
              : 'bg-yellow-400/20 text-yellow-400 hover:bg-yellow-400/30'
          )}
        >
          {event.buttonText}
        </Button>
      </div>
    </div>
  );
};
