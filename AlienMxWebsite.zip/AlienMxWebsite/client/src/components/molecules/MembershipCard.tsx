import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/atoms/Button';
import { Badge } from '@/components/atoms/Badge';
import { MembershipTier } from '@/types';

interface MembershipCardProps {
  tier: MembershipTier;
  className?: string;
}

export const MembershipCard: React.FC<MembershipCardProps> = ({ tier, className }) => {
  return (
    <div className={cn(
      'membership-card rounded-xl overflow-hidden border border-gray-700 bg-alien-dark hover-grow transition duration-300',
      tier.isPopular && 'transform scale-105 shadow-lg border-alien-teal shadow-alien-teal/20',
      className
    )}>
      <div 
        className={cn(
          'h-40 flex items-center justify-center relative overflow-hidden',
          `bg-gradient-to-br from-${tier.gradient.from}/50 to-${tier.gradient.to}/20`
        )}
      >
        {tier.isPopular && (
          <div className="absolute inset-0 opacity-20">
            <div className="absolute rounded-full w-40 h-40 bg-alien-teal/30 top-10 -left-10"></div>
            <div className="absolute rounded-full w-40 h-40 bg-blue-500/30 -bottom-10 -right-10"></div>
          </div>
        )}
        <span className={cn(
          "material-icons text-6xl relative z-10",
          `text-${tier.gradient.from}`
        )}>
          {tier.icon}
        </span>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className={cn(
            "font-space text-xl font-bold",
            `text-${tier.gradient.from}`
          )}>
            {tier.name}
          </h3>
          {tier.isPopular && (
            <Badge variant="info">POPULAR</Badge>
          )}
        </div>
        <p className="text-gray-300 mb-4">{tier.description}</p>
        <ul className="space-y-2 mb-6">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className="material-icons text-alien-green mr-2 text-sm">check_circle</span>
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
        <div className="flex justify-between items-end">
          <span className="text-2xl font-space font-bold">
            ${tier.price}<span className="text-sm text-gray-400">/mes</span>
          </span>
          <Button 
            size="sm"
            className={`bg-gradient-to-r from-${tier.buttonGradient.from} to-${tier.buttonGradient.to} text-alien-dark font-medium`}
          >
            Seleccionar
          </Button>
        </div>
      </div>
    </div>
  );
};
