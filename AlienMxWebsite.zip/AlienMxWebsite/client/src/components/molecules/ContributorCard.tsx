import React from 'react';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/atoms/Avatar';
import { User } from '@/types';

interface ContributorCardProps {
  contributor: User;
  className?: string;
}

export const ContributorCard: React.FC<ContributorCardProps> = ({ 
  contributor, 
  className 
}) => {
  return (
    <div className={cn(
      'flex items-center justify-between mb-4',
      className
    )}>
      <div className="flex items-center">
        <Avatar 
          src={contributor.avatar || ''} 
          alt={`Avatar de ${contributor.username}`} 
          size="sm"
          className="mr-3" 
        />
        <div>
          <div className="font-medium">{contributor.username}</div>
          <div className="text-xs text-gray-400">
            Nivel {contributor.level} • {contributor.role}
          </div>
        </div>
      </div>
      <div className="bg-alien-green/20 text-alien-green px-2 py-1 rounded-full text-xs font-bold">
        {contributor.points?.toLocaleString()} pts
      </div>
    </div>
  );
};
