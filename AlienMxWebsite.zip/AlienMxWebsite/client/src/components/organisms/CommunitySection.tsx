import React from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { Button } from '@/components/atoms/Button';
import { ForumThread } from '@/components/molecules/ForumThread';
import { ContributorCard } from '@/components/molecules/ContributorCard';
import { EventCard } from '@/components/molecules/EventCard';
import { ForumPost, User, Event } from '@/types';

interface CommunitySectionProps {
  className?: string;
}

const forumPosts: ForumPost[] = [
  {
    id: 1,
    title: 'Análisis de las recientes declaraciones gubernamentales',
    content: '¿Qué opinan sobre el último informe publicado? Hay detalles que parecen confirmar lo que muchos hemos estado diciendo por años acerca de la presencia extraterrestre...',
    author: {
      id: 1,
      username: 'Marina85',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150',
      level: 28
    },
    timestamp: 'Hace 2 horas',
    comments: 42,
    category: 'Análisis'
  },
  {
    id: 2,
    title: 'Avistamiento en Sierra de Chihuahua - Necesito ayuda',
    content: 'Anoche presencié algo inexplicable en la sierra. Logré capturar algunas fotos pero la calidad no es muy buena. ¿Podría alguien ayudarme a analizarlas?',
    author: {
      id: 2,
      username: 'AstroCarlos',
      avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150',
      level: 32
    },
    timestamp: 'Hace 11 horas',
    comments: 23,
    category: 'Avistamiento'
  },
  {
    id: 3,
    title: 'Expedición a la Zona del Silencio - Busco participantes',
    content: 'Estoy organizando una expedición para finales de noviembre a la Zona del Silencio. Busco personas con experiencia en investigación de campo y equipo especializado...',
    author: {
      id: 3,
      username: 'Dr_Enigma',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150',
      level: 45
    },
    timestamp: 'Ayer',
    comments: 57,
    category: 'Evento'
  }
];

const topContributors: User[] = [
  {
    id: 2,
    username: 'AstroCarlos',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100',
    level: 32,
    role: 'Investigador',
    points: 3450
  },
  {
    id: 1,
    username: 'Marina85',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100',
    level: 28,
    role: 'Analista',
    points: 2890
  },
  {
    id: 3,
    username: 'Dr_Enigma',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100',
    level: 45,
    role: 'Maestro',
    points: 5122
  }
];

const upcomingEvents: Event[] = [
  {
    id: 1,
    title: 'Live Chat: Análisis de Casos Históricos',
    description: 'Transmisión en vivo con expertos analizando casos emblemáticos de la ufología mexicana.',
    date: '18 Nov, 20:00',
    buttonText: 'Recordatorio',
    buttonVariant: 'reminder'
  },
  {
    id: 2,
    title: 'Expedición: Zona del Silencio',
    description: 'Viaje de investigación a una de las zonas más enigmáticas de México. Nivel: Avanzado.',
    date: '25-28 Nov',
    buttonText: '5 plazas restantes',
    buttonVariant: 'spots'
  }
];

export const CommunitySection: React.FC<CommunitySectionProps> = ({ className }) => {
  return (
    <section className={cn(
      'py-16 bg-alien-dark',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-space text-3xl font-bold mb-4">
            Comunidad <GradientText>Galáctica</GradientText>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Únete a miles de entusiastas que comparten experiencias, investigaciones y teorías sobre fenómenos extraterrestres.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Forum/Discussions Column */}
          <div className="lg:col-span-2">
            <div className="bg-alien-blue rounded-xl overflow-hidden border border-gray-700">
              <div className="p-4 bg-alien-darker border-b border-gray-700 flex justify-between items-center">
                <h3 className="font-space font-bold text-xl">Discusiones Recientes</h3>
                <button className="text-alien-teal hover:text-white flex items-center transition text-sm">
                  Ver todas <span className="material-icons ml-1 text-sm">arrow_forward</span>
                </button>
              </div>
              
              {/* Forum threads */}
              <div className="divide-y divide-gray-700">
                {forumPosts.map(post => (
                  <ForumThread key={post.id} post={post} />
                ))}
              </div>
            </div>
          </div>
          
          {/* Community Sidebar */}
          <div className="space-y-6">
            {/* Top Contributors */}
            <div className="bg-alien-blue rounded-xl overflow-hidden border border-gray-700">
              <div className="p-4 bg-alien-darker border-b border-gray-700">
                <h3 className="font-space font-bold">Top Contribuyentes</h3>
              </div>
              <div className="p-4">
                {topContributors.map(contributor => (
                  <ContributorCard 
                    key={contributor.id}
                    contributor={contributor}
                    className={contributor.id !== topContributors.length ? 'mb-4' : ''}
                  />
                ))}
              </div>
            </div>
            
            {/* Upcoming Events */}
            <div className="bg-alien-blue rounded-xl overflow-hidden border border-gray-700">
              <div className="p-4 bg-alien-darker border-b border-gray-700">
                <h3 className="font-space font-bold">Próximos Eventos</h3>
              </div>
              <div className="divide-y divide-gray-700">
                {upcomingEvents.map(event => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            </div>
            
            {/* Join CTA */}
            <div className="bg-gradient-to-br from-alien-purple/50 to-alien-blue p-6 rounded-xl border border-alien-teal/30">
              <h3 className="font-space font-bold text-xl mb-2">¿Eres testigo o investigador?</h3>
              <p className="text-gray-300 text-sm mb-4">Únete a nuestra comunidad para compartir experiencias y contribuir a la investigación colectiva.</p>
              <Button fullWidth>
                UNIRSE AHORA
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
