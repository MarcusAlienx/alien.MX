import React from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { MembershipCard } from '@/components/molecules/MembershipCard';
import { MembershipTier } from '@/types';

interface MembershipTiersProps {
  className?: string;
}

const membershipTiers: MembershipTier[] = [
  {
    id: 1,
    name: 'Plan Planetario',
    description: 'Para entusiastas casuales que inician su viaje cósmico.',
    price: 199,
    icon: 'public',
    features: [
      'Acceso al foro de la comunidad',
      'Boletín mensual de avistamientos',
      '5% descuento en la tienda'
    ],
    gradient: {
      from: 'amber-700',
      to: 'amber-500'
    },
    buttonGradient: {
      from: 'amber-700',
      to: 'amber-500'
    }
  },
  {
    id: 2,
    name: 'Plan Interestelar',
    description: 'Para investigadores activos y participantes de la comunidad.',
    price: 399,
    icon: 'rocket_launch',
    features: [
      'Todo lo del Plan Planetario',
      'Acceso a webinars mensuales',
      'Mapas de avistamientos en alta resolución',
      '15% descuento en la tienda'
    ],
    isPopular: true,
    gradient: {
      from: 'alien-teal',
      to: 'blue-500'
    },
    buttonGradient: {
      from: 'alien-teal',
      to: 'blue-500'
    }
  },
  {
    id: 3,
    name: 'Plan Galáctico',
    description: 'Para verdaderos creyentes y exploradores comprometidos.',
    price: 899,
    icon: 'stars',
    features: [
      'Todo lo del Plan Interestelar',
      'Expediciones anuales a zonas de avistamientos',
      'Entrevistas con investigadores',
      '25% descuento en la tienda'
    ],
    gradient: {
      from: 'alien-green',
      to: 'yellow-400'
    },
    buttonGradient: {
      from: 'alien-green',
      to: 'yellow-400'
    }
  }
];

export const MembershipTiers: React.FC<MembershipTiersProps> = ({ className }) => {
  return (
    <section className={cn(
      'py-20 bg-alien-blue',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-space text-3xl md:text-4xl font-bold mb-4">
            Membresías <GradientText>Planetarias</GradientText>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Únete a nuestra comunidad y accede a experiencias exclusivas según el nivel de tu membresía.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {membershipTiers.map(tier => (
            <MembershipCard 
              key={tier.id}
              tier={tier}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
