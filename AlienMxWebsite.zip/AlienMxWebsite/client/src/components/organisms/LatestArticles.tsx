import React from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { ArticleCard } from '@/components/molecules/ArticleCard';
import { Article } from '@/types';

interface LatestArticlesProps {
  className?: string;
}

const articles: Article[] = [
  {
    id: 1,
    title: 'Los Patrones Ocultos: Analizando Avistamientos Recurrentes',
    excerpt: 'Un análisis estadístico de los avistamientos en la última década revela patrones temporales y geográficos que podrían indicar una presencia constante...',
    image: 'https://images.unsplash.com/photo-1465101162946-4377e57745c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400',
    category: 'Investigación',
    date: '12 Nov, 2023',
    author: {
      id: 2,
      username: 'Dr. Carlos Ramírez',
      avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50'
    },
    views: 1800,
    comments: 34
  },
  {
    id: 2,
    title: 'Arqueoastronomía: Las Pirámides como Faros Cósmicos',
    excerpt: 'Un nuevo estudio sugiere que las pirámides mesoamericanas podrían haber funcionado como puntos de referencia para navegantes espaciales, según alineaciones astronómicas precisas...',
    image: 'https://pixabay.com/get/g24292c88824892ce7e33f41ff1c0a70f432b4ab3a9c8652cb37f9d7f090f652b87bf9d5dc34247132c661392b1e7622e6b0be65146373ee3b4d0ce4c3b782cf5_1280.jpg',
    category: 'Historia',
    date: '8 Nov, 2023',
    author: {
      id: 1,
      username: 'Dra. Marina López',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50'
    },
    views: 2500,
    comments: 49
  },
  {
    id: 3,
    title: 'Desclasificado: Los Archivos OVNI del Ejército Mexicano',
    excerpt: 'Un reciente proceso de transparencia ha permitido acceder a documentos militares previamente confidenciales que registran encuentros con fenómenos aéreos anómalos...',
    image: 'https://images.unsplash.com/photo-1567427018141-0584cfcbf1b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400',
    category: 'Revelaciones',
    date: '1 Nov, 2023',
    author: {
      id: 3,
      username: 'Alejandro Méndez',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50'
    },
    views: 4200,
    comments: 87
  }
];

export const LatestArticles: React.FC<LatestArticlesProps> = ({ className }) => {
  return (
    <section className={cn(
      'py-16 bg-gradient-to-b from-alien-dark to-alien-blue',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-10">
          <h2 className="font-space text-3xl font-bold">
            Últimos <GradientText>Artículos</GradientText>
          </h2>
          <a href="#" className="text-alien-teal hover:text-white flex items-center transition">
            Ver más <span className="material-icons ml-1">arrow_forward</span>
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map(article => (
            <ArticleCard
              key={article.id}
              article={article}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
