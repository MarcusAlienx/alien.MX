import React from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { ProductCard } from '@/components/molecules/ProductCard';
import { Product } from '@/types';

interface FeaturedProductsProps {
  className?: string;
}

const featuredProducts: Product[] = [
  {
    id: 1,
    name: 'Telescopio NightWatcher Pro',
    description: 'Telescopio astronómico avanzado para observación de fenómenos celestes.',
    price: 8499,
    originalPrice: 9999,
    image: 'https://images.unsplash.com/photo-1482160549825-59d1b23cb208?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800',
    rating: 4,
    reviews: 42,
    badge: 'new'
  },
  {
    id: 2,
    name: 'Camiseta "They\'re Here"',
    description: 'Camiseta 100% algodón con diseño exclusivo de alien.mx',
    price: 499,
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800',
    rating: 5,
    reviews: 127,
    badge: 'popular'
  },
  {
    id: 3,
    name: 'Modelo OVNI TR-3B',
    description: 'Modelo a escala del legendario TR-3B con luces LED.',
    price: 1299,
    image: 'https://images.unsplash.com/photo-1527066579998-dbbae57f45ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800',
    rating: 4.5,
    reviews: 86
  },
  {
    id: 4,
    name: 'Guía de Contactos: Edición 2023',
    description: 'La guía más completa sobre contactos extraterrestres y protocolos.',
    price: 699,
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800',
    rating: 4,
    reviews: 53,
    badge: 'limited'
  }
];

export const FeaturedProducts: React.FC<FeaturedProductsProps> = ({ className }) => {
  return (
    <section className={cn(
      'py-16 bg-alien-dark',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-10">
          <h2 className="font-space text-3xl font-bold">
            Tienda <GradientText>Galáctica</GradientText>
          </h2>
          <a href="#" className="text-alien-teal hover:text-white flex items-center transition">
            Ver todo <span className="material-icons ml-1">arrow_forward</span>
          </a>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
