import React from 'react';
import { useCartStore } from '@/lib/store';
import { motion } from 'framer-motion';
import { CartItem as CartItemType } from '@/types';
import { CartItem } from '@/components/molecules/CartItem';

export const CheckoutReview: React.FC = () => {
  const { 
    items, 
    checkoutInfo, 
    summary,
    appliedPromo,
    shippingMethods
  } = useCartStore();
  
  // Obtener el método de envío seleccionado
  const selectedShipping = shippingMethods.find(
    method => method.id === checkoutInfo.shippingMethod
  );

  return (
    <div className="space-y-6">
      {/* Resumen de productos */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Productos ({items.length})</h3>
        <div className="space-y-3">
          {items.map((item) => (
            <motion.div 
              key={item.product.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="border border-gray-800 rounded-lg overflow-hidden"
            >
              <CartItem item={item} minimal />
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Información de contacto y envío */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Información de contacto</h3>
        <div className="bg-alien-blue/20 p-3 rounded-lg mb-4">
          <p className="text-sm mb-1"><span className="text-gray-400">Nombre: </span>{`${checkoutInfo.contactInfo.firstName} ${checkoutInfo.contactInfo.lastName}`}</p>
          <p className="text-sm mb-1"><span className="text-gray-400">Email: </span>{checkoutInfo.contactInfo.email}</p>
          {checkoutInfo.contactInfo.phone && (
            <p className="text-sm"><span className="text-gray-400">Teléfono: </span>{checkoutInfo.contactInfo.phone}</p>
          )}
        </div>
        
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Dirección de envío</h3>
        <div className="bg-alien-blue/20 p-3 rounded-lg mb-4">
          <p className="text-sm mb-1">{checkoutInfo.shippingAddress.address1}</p>
          {checkoutInfo.shippingAddress.address2 && (
            <p className="text-sm mb-1">{checkoutInfo.shippingAddress.address2}</p>
          )}
          <p className="text-sm mb-1">
            {checkoutInfo.shippingAddress.city}, {checkoutInfo.shippingAddress.state} {checkoutInfo.shippingAddress.zipCode}
          </p>
          <p className="text-sm">{checkoutInfo.shippingAddress.country}</p>
        </div>
        
        {!checkoutInfo.billingAddress.sameAsShipping && (
          <>
            <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Dirección de facturación</h3>
            <div className="bg-alien-blue/20 p-3 rounded-lg mb-4">
              <p className="text-sm mb-1">{checkoutInfo.billingAddress.address1}</p>
              {checkoutInfo.billingAddress.address2 && (
                <p className="text-sm mb-1">{checkoutInfo.billingAddress.address2}</p>
              )}
              <p className="text-sm mb-1">
                {checkoutInfo.billingAddress.city}, {checkoutInfo.billingAddress.state} {checkoutInfo.billingAddress.zipCode}
              </p>
              <p className="text-sm">{checkoutInfo.billingAddress.country}</p>
            </div>
          </>
        )}
      </div>
      
      {/* Método de envío */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Método de envío</h3>
        <div className="bg-alien-blue/20 p-3 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-medium">{selectedShipping?.name}</p>
              <p className="text-sm text-gray-400">{selectedShipping?.description}</p>
            </div>
            <div className="text-right">
              <p className="font-medium text-alien-teal">${selectedShipping?.price.toLocaleString()}</p>
              <p className="text-xs text-gray-400">{selectedShipping?.estimatedDays}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Método de pago */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Método de pago</h3>
        <div className="bg-alien-blue/20 p-3 rounded-lg">
          {checkoutInfo.paymentMethod === 'credit_card' && (
            <div className="flex items-center">
              <span className="material-icons text-alien-teal mr-2">credit_card</span>
              <p>Tarjeta de crédito / débito</p>
            </div>
          )}
          
          {checkoutInfo.paymentMethod === 'paypal' && (
            <div className="flex items-center">
              <span className="material-icons text-blue-400 mr-2">account_balance_wallet</span>
              <p>PayPal</p>
            </div>
          )}
          
          {checkoutInfo.paymentMethod === 'crypto' && (
            <div className="flex items-center">
              <span className="material-icons text-yellow-500 mr-2">currency_bitcoin</span>
              <p>Criptomonedas</p>
            </div>
          )}
          
          {checkoutInfo.paymentMethod === 'bank_transfer' && (
            <div className="flex items-center">
              <span className="material-icons text-green-500 mr-2">account_balance</span>
              <p>Transferencia bancaria</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Notas adicionales */}
      {checkoutInfo.orderNotes && (
        <div>
          <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Notas adicionales</h3>
          <div className="bg-alien-blue/20 p-3 rounded-lg">
            <p className="text-sm">{checkoutInfo.orderNotes}</p>
          </div>
        </div>
      )}
      
      {/* Resumen del costo */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Resumen</h3>
        <div className="bg-alien-blue/20 p-3 rounded-lg">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Subtotal ({items.length} {items.length === 1 ? 'producto' : 'productos'})</span>
              <span>${summary.subtotal.toLocaleString()}</span>
            </div>
            
            {appliedPromo && appliedPromo.isValid && (
              <div className="flex justify-between text-sm">
                <span className="text-alien-teal flex items-center">
                  <span className="material-icons text-sm mr-1">local_offer</span>
                  Descuento ({appliedPromo.code})
                </span>
                <span className="text-alien-teal">-${summary.discount.toLocaleString()}</span>
              </div>
            )}
            
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Envío ({selectedShipping?.name})</span>
              <span>${summary.shippingCost.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">IVA (16%)</span>
              <span>${summary.tax.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between text-lg font-medium pt-2 border-t border-gray-700">
              <span>Total</span>
              <span className="text-alien-green">${summary.total.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Términos y condiciones */}
      <div className="pt-2">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="terms"
            className="w-4 h-4 mr-2 accent-alien-teal"
            defaultChecked
          />
          <label htmlFor="terms" className="text-sm">
            He leído y acepto los <a href="#" className="text-alien-teal hover:underline">términos y condiciones</a> y <a href="#" className="text-alien-teal hover:underline">políticas de privacidad</a>
          </label>
        </div>
      </div>
    </div>
  );
};