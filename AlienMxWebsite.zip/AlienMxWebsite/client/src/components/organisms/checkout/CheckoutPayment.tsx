import React from 'react';
import { useCartStore, PaymentMethod } from '@/lib/store';
import { motion } from 'framer-motion';

export const CheckoutPayment: React.FC = () => {
  const { checkoutInfo, updateCheckoutInfo } = useCartStore();
  
  const handleSelectPayment = (method: PaymentMethod) => {
    updateCheckoutInfo({ paymentMethod: method });
  };
  
  // Información adicional según el método de pago
  const renderPaymentDetails = () => {
    switch (checkoutInfo.paymentMethod) {
      case 'credit_card':
        return (
          <div className="mt-4 space-y-3">
            <div>
              <label htmlFor="cardNumber" className="block text-sm mb-1">Número de tarjeta *</label>
              <div className="relative">
                <input
                  type="text"
                  id="cardNumber"
                  placeholder="0000 0000 0000 0000"
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal pl-10"
                />
                <span className="material-icons absolute left-3 top-2 text-gray-500">credit_card</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="expiry" className="block text-sm mb-1">Fecha de expiración *</label>
                <input
                  type="text"
                  id="expiry"
                  placeholder="MM/AA"
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                />
              </div>
              <div>
                <label htmlFor="cvc" className="block text-sm mb-1">CVC / CVV *</label>
                <input
                  type="text"
                  id="cvc"
                  placeholder="123"
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="nameOnCard" className="block text-sm mb-1">Nombre en la tarjeta *</label>
              <input
                type="text"
                id="nameOnCard"
                placeholder="Nombre como aparece en la tarjeta"
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
              />
            </div>
          </div>
        );
        
      case 'paypal':
        return (
          <div className="mt-4 p-4 border border-gray-700 rounded-lg bg-alien-blue/10">
            <p className="text-sm text-center mb-4">
              Serás redirigido a PayPal para completar tu pago después de revisar tu pedido.
            </p>
            <div className="flex justify-center">
              <img src="https://www.paypalobjects.com/webstatic/mktg/logo/pp_cc_mark_111x69.jpg" alt="PayPal" className="h-10" />
            </div>
          </div>
        );
        
      case 'crypto':
        return (
          <div className="mt-4 space-y-4">
            <div className="p-4 border border-gray-700 rounded-lg bg-alien-blue/10">
              <p className="text-sm mb-2">Aceptamos las siguientes criptomonedas:</p>
              <div className="flex flex-wrap gap-2">
                <div className="px-3 py-1 bg-gray-800 rounded-full text-xs flex items-center">
                  <span className="w-3 h-3 bg-yellow-500 rounded-full mr-1"></span>
                  Bitcoin
                </div>
                <div className="px-3 py-1 bg-gray-800 rounded-full text-xs flex items-center">
                  <span className="w-3 h-3 bg-blue-500 rounded-full mr-1"></span>
                  Ethereum
                </div>
                <div className="px-3 py-1 bg-gray-800 rounded-full text-xs flex items-center">
                  <span className="w-3 h-3 bg-green-500 rounded-full mr-1"></span>
                  USDC
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-400">
              Recibirás las instrucciones de pago después de completar tu pedido. Las criptomonedas serán convertidas a tu moneda local utilizando la tasa de cambio vigente al momento de la transacción.
            </p>
          </div>
        );
        
      case 'bank_transfer':
        return (
          <div className="mt-4 space-y-4">
            <div className="p-4 border border-gray-700 rounded-lg bg-alien-blue/10">
              <p className="text-sm mb-3">Información bancaria:</p>
              <table className="w-full text-xs">
                <tbody>
                  <tr>
                    <td className="py-1 text-gray-400">Banco:</td>
                    <td>Banco Intergaláctico S.A.</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-400">Beneficiario:</td>
                    <td>Alien MX S.A. de C.V.</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-400">CLABE:</td>
                    <td>012 345 678 901 234 567</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-gray-400">Cuenta:</td>
                    <td>987654321</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-400">
              Tu pedido será procesado una vez que se confirme tu pago. Por favor utiliza tu número de pedido como referencia en la transferencia.
            </p>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="space-y-3">
        {/* Método de pago: Tarjeta de crédito */}
        <motion.div 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={`border ${
            checkoutInfo.paymentMethod === 'credit_card'
              ? 'border-alien-teal bg-alien-teal/10'
              : 'border-gray-700 bg-alien-blue/20 hover:bg-alien-blue/30'
          } rounded-lg p-4 cursor-pointer transition-colors`}
          onClick={() => handleSelectPayment('credit_card')}
        >
          <div className="flex items-start">
            <div className="mr-3 mt-1">
              <div className={`w-5 h-5 rounded-full border-2 ${
                checkoutInfo.paymentMethod === 'credit_card'
                  ? 'border-alien-teal flex items-center justify-center'
                  : 'border-gray-500'
              }`}>
                {checkoutInfo.paymentMethod === 'credit_card' && (
                  <div className="w-3 h-3 rounded-full bg-alien-teal" />
                )}
              </div>
            </div>
            
            <div className="flex-grow">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Tarjeta de crédito / débito</h3>
                <div className="flex space-x-1">
                  <div className="w-8 h-5 bg-blue-800 rounded"></div>
                  <div className="w-8 h-5 bg-green-800 rounded"></div>
                  <div className="w-8 h-5 bg-red-800 rounded"></div>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-1">Pago seguro con tarjeta bancaria</p>
            </div>
          </div>
        </motion.div>
        
        {/* Método de pago: PayPal */}
        <motion.div 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={`border ${
            checkoutInfo.paymentMethod === 'paypal'
              ? 'border-alien-teal bg-alien-teal/10'
              : 'border-gray-700 bg-alien-blue/20 hover:bg-alien-blue/30'
          } rounded-lg p-4 cursor-pointer transition-colors`}
          onClick={() => handleSelectPayment('paypal')}
        >
          <div className="flex items-start">
            <div className="mr-3 mt-1">
              <div className={`w-5 h-5 rounded-full border-2 ${
                checkoutInfo.paymentMethod === 'paypal'
                  ? 'border-alien-teal flex items-center justify-center'
                  : 'border-gray-500'
              }`}>
                {checkoutInfo.paymentMethod === 'paypal' && (
                  <div className="w-3 h-3 rounded-full bg-alien-teal" />
                )}
              </div>
            </div>
            
            <div className="flex-grow">
              <h3 className="font-medium">PayPal</h3>
              <p className="text-sm text-gray-400 mt-1">Pago rápido y seguro con PayPal</p>
            </div>
          </div>
        </motion.div>
        
        {/* Método de pago: Criptomonedas */}
        <motion.div 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={`border ${
            checkoutInfo.paymentMethod === 'crypto'
              ? 'border-alien-teal bg-alien-teal/10'
              : 'border-gray-700 bg-alien-blue/20 hover:bg-alien-blue/30'
          } rounded-lg p-4 cursor-pointer transition-colors`}
          onClick={() => handleSelectPayment('crypto')}
        >
          <div className="flex items-start">
            <div className="mr-3 mt-1">
              <div className={`w-5 h-5 rounded-full border-2 ${
                checkoutInfo.paymentMethod === 'crypto'
                  ? 'border-alien-teal flex items-center justify-center'
                  : 'border-gray-500'
              }`}>
                {checkoutInfo.paymentMethod === 'crypto' && (
                  <div className="w-3 h-3 rounded-full bg-alien-teal" />
                )}
              </div>
            </div>
            
            <div className="flex-grow">
              <h3 className="font-medium">Criptomonedas</h3>
              <p className="text-sm text-gray-400 mt-1">Paga con Bitcoin, Ethereum y otras criptomonedas</p>
            </div>
          </div>
        </motion.div>
        
        {/* Método de pago: Transferencia bancaria */}
        <motion.div 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={`border ${
            checkoutInfo.paymentMethod === 'bank_transfer'
              ? 'border-alien-teal bg-alien-teal/10'
              : 'border-gray-700 bg-alien-blue/20 hover:bg-alien-blue/30'
          } rounded-lg p-4 cursor-pointer transition-colors`}
          onClick={() => handleSelectPayment('bank_transfer')}
        >
          <div className="flex items-start">
            <div className="mr-3 mt-1">
              <div className={`w-5 h-5 rounded-full border-2 ${
                checkoutInfo.paymentMethod === 'bank_transfer'
                  ? 'border-alien-teal flex items-center justify-center'
                  : 'border-gray-500'
              }`}>
                {checkoutInfo.paymentMethod === 'bank_transfer' && (
                  <div className="w-3 h-3 rounded-full bg-alien-teal" />
                )}
              </div>
            </div>
            
            <div className="flex-grow">
              <h3 className="font-medium">Transferencia bancaria</h3>
              <p className="text-sm text-gray-400 mt-1">Transferencia a cuenta bancaria</p>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Detalles del método de pago seleccionado */}
      {renderPaymentDetails()}
      
      {/* Nota de seguridad */}
      <div className="mt-6 p-4 border border-gray-700 rounded-lg bg-alien-blue/10">
        <h3 className="text-sm font-medium mb-2 flex items-center">
          <span className="material-icons text-alien-teal text-base mr-2">shield</span>
          Pagos seguros
        </h3>
        <p className="text-xs text-gray-400">
          Todos los pagos son procesados de forma segura. Tu información nunca es almacenada en nuestros servidores y se transmite utilizando encriptación de nivel bancario.
        </p>
      </div>
    </div>
  );
};