import React from 'react';
import { useCartStore, CheckoutInfo } from '@/lib/store';

export const CheckoutInformation: React.FC = () => {
  const { checkoutInfo, updateCheckoutInfo } = useCartStore();
  
  // Manejador de cambios en el formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    // Determinar la sección a actualizar
    if (name.startsWith('contact.')) {
      const field = name.replace('contact.', '');
      updateCheckoutInfo({
        contactInfo: {
          ...checkoutInfo.contactInfo,
          [field]: value
        }
      });
    } else if (name.startsWith('shipping.')) {
      const field = name.replace('shipping.', '');
      updateCheckoutInfo({
        shippingAddress: {
          ...checkoutInfo.shippingAddress,
          [field]: value
        }
      });
    } else if (name.startsWith('billing.')) {
      const field = name.replace('billing.', '');
      
      if (field === 'sameAsShipping') {
        updateCheckoutInfo({
          billingAddress: {
            ...checkoutInfo.billingAddress,
            sameAsShipping: (e.target as HTMLInputElement).checked
          }
        });
      } else {
        updateCheckoutInfo({
          billingAddress: {
            ...checkoutInfo.billingAddress,
            [field]: value
          }
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Información de contacto */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Información de contacto</h3>
        <div className="space-y-3">
          <div>
            <label htmlFor="email" className="block text-sm mb-1">Correo electrónico *</label>
            <input
              type="email"
              id="email"
              name="contact.email"
              value={checkoutInfo.contactInfo.email}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
              placeholder="email@ejemplo.com"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="firstName" className="block text-sm mb-1">Nombre *</label>
              <input
                type="text"
                id="firstName"
                name="contact.firstName"
                value={checkoutInfo.contactInfo.firstName}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Tu nombre"
                required
              />
            </div>
            <div>
              <label htmlFor="lastName" className="block text-sm mb-1">Apellido *</label>
              <input
                type="text"
                id="lastName"
                name="contact.lastName"
                value={checkoutInfo.contactInfo.lastName}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Tu apellido"
                required
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="phone" className="block text-sm mb-1">Teléfono</label>
            <input
              type="tel"
              id="phone"
              name="contact.phone"
              value={checkoutInfo.contactInfo.phone || ''}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
              placeholder="(opcional)"
            />
          </div>
        </div>
      </div>
      
      {/* Dirección de envío */}
      <div>
        <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Dirección de envío</h3>
        <div className="space-y-3">
          <div>
            <label htmlFor="address1" className="block text-sm mb-1">Dirección *</label>
            <input
              type="text"
              id="address1"
              name="shipping.address1"
              value={checkoutInfo.shippingAddress.address1}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
              placeholder="Calle y número"
              required
            />
          </div>
          
          <div>
            <label htmlFor="address2" className="block text-sm mb-1">Apartamento, suite, etc.</label>
            <input
              type="text"
              id="address2"
              name="shipping.address2"
              value={checkoutInfo.shippingAddress.address2 || ''}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
              placeholder="(opcional)"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="city" className="block text-sm mb-1">Ciudad *</label>
              <input
                type="text"
                id="city"
                name="shipping.city"
                value={checkoutInfo.shippingAddress.city}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Tu ciudad"
                required
              />
            </div>
            <div>
              <label htmlFor="state" className="block text-sm mb-1">Estado *</label>
              <input
                type="text"
                id="state"
                name="shipping.state"
                value={checkoutInfo.shippingAddress.state}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Tu estado"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="zipCode" className="block text-sm mb-1">Código postal *</label>
              <input
                type="text"
                id="zipCode"
                name="shipping.zipCode"
                value={checkoutInfo.shippingAddress.zipCode}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Tu C.P."
                required
              />
            </div>
            <div>
              <label htmlFor="country" className="block text-sm mb-1">País *</label>
              <select
                id="country"
                name="shipping.country"
                value={checkoutInfo.shippingAddress.country}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                required
              >
                <option value="México">México</option>
                <option value="Estados Unidos">Estados Unidos</option>
                <option value="Canadá">Canadá</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {/* Dirección de facturación */}
      <div>
        <div className="flex items-center mb-3">
          <input
            type="checkbox"
            id="sameAsShipping"
            name="billing.sameAsShipping"
            checked={checkoutInfo.billingAddress.sameAsShipping}
            onChange={handleChange}
            className="w-4 h-4 mr-2 accent-alien-teal"
          />
          <label htmlFor="sameAsShipping" className="text-sm">
            La dirección de facturación es la misma que la de envío
          </label>
        </div>
        
        {!checkoutInfo.billingAddress.sameAsShipping && (
          <div className="space-y-3 mt-3 pt-3 border-t border-gray-800">
            <h3 className="text-sm uppercase font-medium text-gray-400 mb-3">Dirección de facturación</h3>
            
            <div>
              <label htmlFor="billingAddress1" className="block text-sm mb-1">Dirección *</label>
              <input
                type="text"
                id="billingAddress1"
                name="billing.address1"
                value={checkoutInfo.billingAddress.address1 || ''}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="Calle y número"
                required={!checkoutInfo.billingAddress.sameAsShipping}
              />
            </div>
            
            <div>
              <label htmlFor="billingAddress2" className="block text-sm mb-1">Apartamento, suite, etc.</label>
              <input
                type="text"
                id="billingAddress2"
                name="billing.address2"
                value={checkoutInfo.billingAddress.address2 || ''}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                placeholder="(opcional)"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="billingCity" className="block text-sm mb-1">Ciudad *</label>
                <input
                  type="text"
                  id="billingCity"
                  name="billing.city"
                  value={checkoutInfo.billingAddress.city || ''}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                  placeholder="Tu ciudad"
                  required={!checkoutInfo.billingAddress.sameAsShipping}
                />
              </div>
              <div>
                <label htmlFor="billingState" className="block text-sm mb-1">Estado *</label>
                <input
                  type="text"
                  id="billingState"
                  name="billing.state"
                  value={checkoutInfo.billingAddress.state || ''}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                  placeholder="Tu estado"
                  required={!checkoutInfo.billingAddress.sameAsShipping}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="billingZipCode" className="block text-sm mb-1">Código postal *</label>
                <input
                  type="text"
                  id="billingZipCode"
                  name="billing.zipCode"
                  value={checkoutInfo.billingAddress.zipCode || ''}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                  placeholder="Tu C.P."
                  required={!checkoutInfo.billingAddress.sameAsShipping}
                />
              </div>
              <div>
                <label htmlFor="billingCountry" className="block text-sm mb-1">País *</label>
                <select
                  id="billingCountry"
                  name="billing.country"
                  value={checkoutInfo.billingAddress.country || 'México'}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal"
                  required={!checkoutInfo.billingAddress.sameAsShipping}
                >
                  <option value="México">México</option>
                  <option value="Estados Unidos">Estados Unidos</option>
                  <option value="Canadá">Canadá</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};