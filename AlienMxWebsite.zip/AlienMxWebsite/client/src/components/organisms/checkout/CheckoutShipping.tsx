import React from 'react';
import { useCartStore, ShippingMethod } from '@/lib/store';
import { motion } from 'framer-motion';

export const CheckoutShipping: React.FC = () => {
  const { shippingMethods, checkoutInfo, selectShippingMethod } = useCartStore();

  const handleSelectShipping = (methodId: string) => {
    selectShippingMethod(methodId);
  };

  return (
    <div>
      <div className="space-y-3">
        {shippingMethods.map((method) => (
          <motion.div 
            key={method.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`border ${
              checkoutInfo.shippingMethod === method.id
                ? 'border-alien-teal bg-alien-teal/10'
                : 'border-gray-700 bg-alien-blue/20 hover:bg-alien-blue/30'
            } rounded-lg p-4 cursor-pointer transition-colors`}
            onClick={() => handleSelectShipping(method.id)}
          >
            <div className="flex items-start">
              <div className="mr-3 mt-1">
                <div className={`w-5 h-5 rounded-full border-2 ${
                  checkoutInfo.shippingMethod === method.id
                    ? 'border-alien-teal flex items-center justify-center'
                    : 'border-gray-500'
                }`}>
                  {checkoutInfo.shippingMethod === method.id && (
                    <div className="w-3 h-3 rounded-full bg-alien-teal" />
                  )}
                </div>
              </div>
              
              <div className="flex-grow">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium">{method.name}</h3>
                    <p className="text-sm text-gray-400 mt-1">{method.description}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-medium text-alien-teal">${method.price.toLocaleString()}</span>
                    <p className="text-xs text-gray-400 mt-1">{method.estimatedDays}</p>
                  </div>
                </div>
                
                {method.id === 'same_day' && (
                  <div className="mt-2 p-2 bg-gray-800/50 rounded text-xs text-gray-300">
                    <span className="material-icons text-amber-400 text-xs align-middle mr-1">schedule</span>
                    Pedidos antes de las 2PM serán entregados el mismo día.
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-6 p-4 border border-gray-700 rounded-lg bg-alien-blue/10">
        <h3 className="text-sm font-medium mb-2 flex items-center">
          <span className="material-icons text-alien-teal text-base mr-2">info</span>
          Información de envío
        </h3>
        <ul className="space-y-2 text-sm text-gray-400">
          <li className="flex items-start">
            <span className="material-icons text-xs mr-2 mt-1">check</span>
            Todos los envíos incluyen número de seguimiento
          </li>
          <li className="flex items-start">
            <span className="material-icons text-xs mr-2 mt-1">check</span>
            Envíos internacionales pueden tener cargos adicionales por impuestos
          </li>
          <li className="flex items-start">
            <span className="material-icons text-xs mr-2 mt-1">check</span>
            Las entregas se realizan en días hábiles (lunes a viernes)
          </li>
        </ul>
      </div>
      
      <div className="mt-6">
        <label htmlFor="orderNotes" className="block text-sm mb-2">Notas adicionales (opcional)</label>
        <textarea
          id="orderNotes"
          placeholder="Instrucciones especiales para la entrega"
          className="w-full px-3 py-2 bg-alien-blue/30 border border-gray-700 rounded focus:outline-none focus:ring-1 focus:ring-alien-teal h-24 resize-none"
          value={checkoutInfo.orderNotes || ''}
          onChange={(e) => useCartStore.getState().updateCheckoutInfo({ orderNotes: e.target.value })}
        />
      </div>
    </div>
  );
};