import React from 'react';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/atoms/Logo';

interface FooterProps {
  className?: string;
}

export const Footer: React.FC<FooterProps> = ({ className }) => {
  return (
    <footer className={cn(
      'bg-alien-darker py-12 border-t border-alien-green/20',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div>
            <Logo size="sm" className="mb-6" />
            <p className="text-sm text-gray-400 mb-4">
              La comunidad más grande de México dedicada a la investigación y divulgación de fenómenos extraterrestres.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-alien-green transition">
                <span className="material-icons">facebook</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-alien-green transition">
                <span className="material-icons">twitter</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-alien-green transition">
                <span className="material-icons">youtube_activity</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-alien-green transition">
                <span className="material-icons">podcasts</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-space font-bold mb-4 text-white">Explora</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Avistamientos</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Tienda</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Comunidad</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Membresías</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Podcast</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Eventos</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-space font-bold mb-4 text-white">Recursos</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Base de datos OVNI</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Guía del investigador</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Glosario ufológico</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Documentos desclasificados</a></li>
              <li><a href="#" className="text-gray-400 hover:text-alien-teal transition">Formatos de reporte</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-space font-bold mb-4 text-white">Contacto</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <span className="material-icons text-alien-teal mr-2 text-base">email</span>
                <span className="text-gray-400">contacto@alien.mx</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-alien-green mr-2 text-base">phone</span>
                <span className="text-gray-400">+52 (55) 1234-5678</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-yellow-400 mr-2 text-base">location_on</span>
                <span className="text-gray-400">CDMX, México<br/>Zona de investigación central</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <div className="text-sm text-gray-500 mb-4 md:mb-0">
            © {new Date().getFullYear()} Alien.mx - Todos los derechos reservados
          </div>
          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
            <a href="#" className="hover:text-alien-teal transition">Términos y Condiciones</a>
            <a href="#" className="hover:text-alien-teal transition">Política de Privacidad</a>
            <a href="#" className="hover:text-alien-teal transition">Cookies</a>
            <a href="#" className="hover:text-alien-teal transition">Accesibilidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
