import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { IconButton } from '@/components/atoms/IconButton';
import { MapMarker } from '@/components/atoms/MapMarker';
import { SightingLocation, SightingStat } from '@/types';

interface SightingsMapProps {
  className?: string;
}

const sightingLocations: SightingLocation[] = [
  {
    id: 1,
    name: 'Bosque de Chapultepec',
    description: 'Avistamiento de luces triangulares sobre el lago.',
    date: '15 de noviembre, 2023',
    lat: 25,
    lng: 33,
    type: 'recent'
  },
  {
    id: 2,
    name: 'Pirámides de Teotihuacán',
    description: 'Objetos esféricos luminosos fotografiados por múltiples turistas.',
    date: '2 de octubre, 2023',
    lat: 33,
    lng: 75,
    type: 'verified'
  },
  {
    id: 3,
    name: 'Zona Arqueológica de Teotihuacán',
    description: 'Múltiples avistamientos de objetos luminosos suspendidos sobre las pirámides. 8 testigos reportaron el evento.',
    date: '24 de octubre, 2023',
    lat: 66,
    lng: 33,
    type: 'investigation',
    witnesses: 8
  }
];

const mapStats: SightingStat[] = [
  { label: 'Total avistamientos', value: '1,247', color: 'white' },
  { label: 'Este mes', value: '+42', color: 'alien-green' },
  { label: 'Verificados', value: '312', color: 'alien-teal' },
  { label: 'Áreas activas', value: '18', color: 'yellow-400' }
];

export const SightingsMap: React.FC<SightingsMapProps> = ({ className }) => {
  const [selectedSighting, setSelectedSighting] = useState<SightingLocation | null>(sightingLocations[2]);
  
  return (
    <section className={cn(
      'py-16 bg-gradient-to-b from-alien-blue to-alien-dark',
      className
    )}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-space text-3xl font-bold mb-4">
            Mapa de <GradientText>Avistamientos</GradientText>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Explora los avistamientos registrados por nuestra comunidad en todo México. Descubre patrones y zonas de actividad.
          </p>
        </div>
        
        {/* Interactive Map */}
        <div className="relative h-[500px] bg-alien-darker rounded-xl overflow-hidden border border-gray-700">
          {/* Map background - stylized map of Mexico */}
          <div className="absolute inset-0 opacity-70">
            <img 
              src="https://pixabay.com/get/g58a17669edf4ae53562b6b8da98358de15c214c74d534b3421eed12ab45450157821ed35e8831667f9ba5a2cde247b55c46296757fcf0f5b40a09d4c82bd0d31_1280.jpg" 
              alt="Mapa de México" 
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Map overlay with grid lines */}
          <div className="absolute inset-0 bg-gradient-to-t from-alien-darker to-transparent opacity-40"></div>
          <div 
            className="absolute inset-0" 
            style={{ 
              backgroundImage: `linear-gradient(rgba(0,240,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,240,255,0.05) 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}
          ></div>
          
          {/* Radar animation center */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="w-40 h-40 rounded-full border border-alien-teal opacity-40"></div>
            <div className="w-40 h-40 rounded-full border border-alien-teal absolute top-0 left-0 radar-pulse"></div>
          </div>
          
          {/* Sighting markers */}
          {sightingLocations.map(location => (
            <MapMarker
              key={location.id}
              type={location.type}
              size={location.type === 'investigation' ? 'lg' : 'md'}
              className={`absolute top-${location.lat}% left-${location.lng}%`}
              onClick={() => setSelectedSighting(location)}
            />
          ))}
          
          {/* Map controls */}
          <div className="absolute bottom-4 left-4 flex space-x-2">
            <IconButton
              icon={<span className="material-icons">add</span>}
              variant="transparent"
            />
            <IconButton
              icon={<span className="material-icons">remove</span>}
              variant="transparent"
            />
          </div>
          
          {/* Map filters */}
          <div className="absolute top-4 right-4 p-3 bg-alien-darker/80 backdrop-blur-sm rounded-lg border border-gray-700">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <span className="w-3 h-3 rounded-full bg-alien-green mr-2"></span>
                <span className="text-sm">Recientes</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 rounded-full bg-alien-teal mr-2"></span>
                <span className="text-sm">Verificados</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 rounded-full bg-yellow-400 mr-2"></span>
                <span className="text-sm">Investigación</span>
              </div>
            </div>
          </div>
          
          {/* Selected sighting details */}
          {selectedSighting && (
            <div className="absolute bottom-4 right-4 p-4 bg-alien-darker/80 backdrop-blur-sm rounded-lg border border-gray-700 max-w-sm">
              <div className="flex items-start">
                <div className={cn(
                  "w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center mr-3",
                  selectedSighting.type === 'recent' ? 'bg-alien-green' :
                  selectedSighting.type === 'verified' ? 'bg-alien-teal' : 'bg-yellow-400'
                )}>
                  <span className="material-icons text-alien-dark">location_on</span>
                </div>
                <div>
                  <h4 className="font-space font-medium text-alien-teal">{selectedSighting.name}</h4>
                  <p className="text-sm text-gray-300 mt-1">{selectedSighting.description}</p>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs text-gray-400">{selectedSighting.date}</span>
                    <button className="text-alien-green text-sm hover:text-white transition">Ver detalles</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Map stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
          {mapStats.map((stat, index) => (
            <div key={index} className="bg-alien-darker p-4 rounded-lg border border-gray-700">
              <div className="text-sm text-gray-400">{stat.label}</div>
              <div className={cn(
                "font-space text-2xl font-bold",
                `text-${stat.color}`
              )}>
                {stat.value}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
