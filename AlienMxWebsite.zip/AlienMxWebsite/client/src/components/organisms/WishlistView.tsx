import React from 'react';
import { useCartStore } from '@/lib/store';
import { Button } from '@/components/atoms/Button';
import { motion, AnimatePresence } from 'framer-motion';
import { apiRequest } from '@/lib/queryClient';
import { Product } from '@/types';
import { useQuery } from '@tanstack/react-query';

export const WishlistView: React.FC = () => {
  const { wishlist, moveToCart, removeFromWishlist } = useCartStore();
  
  // Normalmente, obtendríamos esta información de la API
  // Pero por ahora vamos a simular los datos
  const { data: products, isLoading } = useQuery({
    queryKey: ['products', 'wishlist', wishlist],
    queryFn: async () => {
      // Simulación - en una app real haríamos una llamada a API
      return wishlist.map(id => ({
        id,
        name: `Producto #${id}`,
        description: 'Descripción del producto guardado en tu lista de deseos.',
        price: Math.floor(Math.random() * 5000) + 500,
        image: `https://via.placeholder.com/150?text=Item${id}`,
        rating: 4.5,
        reviews: 10
      })) as Product[];
    },
    enabled: wishlist.length > 0
  });

  if (wishlist.length === 0) {
    return (
      <div className="p-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="py-8 flex flex-col items-center"
        >
          <motion.span 
            className="material-icons text-gray-500 text-5xl mb-4"
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 2, 
              ease: "easeInOut", 
              repeat: Infinity,
              repeatDelay: 1
            }}
          >
            favorite_border
          </motion.span>
          <h3 className="text-lg font-medium mb-2">Tu lista de deseos está vacía</h3>
          <p className="text-gray-400 text-sm mb-6">Guarda tus productos favoritos para después</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <p className="text-sm text-gray-400 mb-4">
        {wishlist.length} {wishlist.length === 1 ? 'producto' : 'productos'} en tu lista de deseos
      </p>
      
      <div className="space-y-4">
        <AnimatePresence>
          {isLoading ? (
            <div className="py-8 text-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="inline-block w-6 h-6 border-2 border-alien-teal border-t-transparent rounded-full"
              />
              <p className="text-sm text-gray-400 mt-2">Cargando productos...</p>
            </div>
          ) : (
            products?.map((product) => (
              <motion.div 
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="bg-alien-blue/20 rounded-lg p-3 flex"
              >
                <div className="w-16 h-16 bg-gray-800 rounded mr-3 overflow-hidden flex-shrink-0">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="flex-grow min-w-0">
                  <h3 className="font-medium text-sm truncate">{product.name}</h3>
                  <p className="text-alien-green text-sm">${product.price.toLocaleString()}</p>
                  
                  <div className="flex space-x-2 mt-2">
                    <Button 
                      variant="primary" 
                      size="sm"
                      onClick={() => moveToCart(product.id, 1)}
                    >
                      <span className="text-xs">Añadir</span>
                    </Button>
                    <Button 
                      variant="tertiary" 
                      size="sm"
                      onClick={() => removeFromWishlist(product.id)}
                    >
                      <span className="material-icons text-sm">delete</span>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
      
      {!isLoading && wishlist.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-6"
        >
          <Button 
            variant="tertiary" 
            fullWidth
            onClick={() => {
              // Añadir todos los productos al carrito
              wishlist.forEach(id => moveToCart(id, 1));
            }}
          >
            Añadir todos al carrito
          </Button>
        </motion.div>
      )}
    </div>
  );
};