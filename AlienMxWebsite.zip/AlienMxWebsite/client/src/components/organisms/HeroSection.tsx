import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/atoms/Button';
import { GradientText } from '@/components/atoms/GradientText';
import { UfoShape } from '@/components/atoms/UfoShape';
import { StarsBackground } from '@/components/atoms/StarsBackground';

interface HeroSectionProps {
  className?: string;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ className }) => {
  return (
    <section className={cn(
      'relative h-screen max-h-[800px] overflow-hidden',
      className
    )}>
      <StarsBackground />
      
      <div className="relative z-10 h-full container mx-auto px-4 flex flex-col justify-center">
        <div className="max-w-3xl">
          <h1 className="font-space text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4">
            <GradientText>Descubre la verdad</GradientText>
            <span className="block text-white">más allá de las estrellas</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl">
            Bienvenido al portal más completo sobre avistamientos, investigaciones y cultura OVNI en México. Conectamos a la comunidad de entusiastas y exploradores de lo desconocido.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg">
              EXPLORAR AVISTAMIENTOS
            </Button>
            <Button size="lg" variant="secondary">
              UNIRSE A LA COMUNIDAD
            </Button>
          </div>
        </div>
      </div>
      
      {/* UFO animated elements */}
      <UfoShape 
        className="absolute bottom-20 right-10 md:right-20 w-24 h-12 animate-float"
        variant="teal"
        glow
      />
      <UfoShape 
        className="absolute top-40 left-[20%] w-16 h-8 animate-float"
        variant="green"
        glow
        style={{ animationDelay: '-2s' }}
      />
      <UfoShape 
        className="absolute top-[30%] right-[15%] w-20 h-10 animate-float"
        variant="teal"
        glow
        style={{ animationDelay: '-4s' }}
      />
    </section>
  );
};
