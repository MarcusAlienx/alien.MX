import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/atoms/Logo';
import { NavLink } from '@/components/atoms/NavLink';
import { IconButton } from '@/components/atoms/IconButton';
import { useCartStore } from '@/lib/store';

interface HeaderProps {
  className?: string;
}

export const Header: React.FC<HeaderProps> = ({ className }) => {
  const [location] = useLocation();
  const { items, openCart } = useCartStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  const totalItems = items.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Close mobile menu when changing route
    setIsMobileMenuOpen(false);
  }, [location]);

  return (
    <header className={cn(
      'bg-alien-dark border-b border-alien-green/20 sticky top-0 z-40 transition-all duration-300',
      isScrolled && 'shadow-lg bg-opacity-90 backdrop-blur-sm',
      className
    )}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Logo />
          
          <nav className={cn(
            'fixed md:relative top-16 md:top-0 left-0 right-0 md:flex space-y-4 md:space-y-0 md:space-x-6 bg-alien-dark md:bg-transparent p-4 md:p-0 border-b border-alien-green/20 md:border-0 z-50 transition-all duration-300 ease-in-out',
            isMobileMenuOpen ? 'block' : 'hidden md:flex'
          )}>
            <NavLink href="/" isActive={location === '/'}>Inicio</NavLink>
            <NavLink href="/product/1" isActive={location.startsWith('/product')}>Tienda</NavLink>
            <NavLink href="/profile" isActive={location.startsWith('/profile')}>Comunidad</NavLink>
            <NavLink href="/sightings" isActive={location.startsWith('/sightings')}>Avistamientos</NavLink>
            <NavLink href="/memberships" isActive={location.startsWith('/memberships')}>Membresías</NavLink>
          </nav>
          
          <div className="flex items-center space-x-4">
            <IconButton 
              icon={<span className="material-icons">search</span>}
              variant="green"
              className="hidden sm:block"
            />
            <IconButton 
              icon={<span className="material-icons">person</span>}
              variant="teal"
              className="hidden sm:block"
              onClick={() => window.location.href = '/profile'}
            />
            <IconButton 
              icon={<span className="material-icons">shopping_cart</span>}
              variant="green"
              badge={totalItems > 0 ? totalItems : undefined}
              onClick={openCart}
            />
            <IconButton 
              icon={<span className="material-icons">menu</span>}
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            />
          </div>
        </div>
      </div>
    </header>
  );
};
