import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useCartStore, CheckoutStage } from '@/lib/store';
import { Button } from '@/components/atoms/Button';

// Componentes de las diferentes etapas del checkout
import { CheckoutInformation } from './checkout/CheckoutInformation';
import { CheckoutShipping } from './checkout/CheckoutShipping';
import { CheckoutPayment } from './checkout/CheckoutPayment';
import { CheckoutReview } from './checkout/CheckoutReview';
import { CheckoutConfirmation } from './checkout/CheckoutConfirmation';

export const Checkout: React.FC = () => {
  const { 
    checkoutInfo, 
    setCheckoutStage,
    items,
    summary,
    processOrder
  } = useCartStore();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Maneja el avance al siguiente paso
  const handleNext = () => {
    const stages: CheckoutStage[] = ['cart', 'information', 'shipping', 'payment', 'review', 'confirmation'];
    const currentIndex = stages.indexOf(checkoutInfo.stage);
    
    if (currentIndex < stages.length - 1) {
      setCheckoutStage(stages[currentIndex + 1]);
    }
  };
  
  // Maneja el retroceso al paso anterior
  const handleBack = () => {
    const stages: CheckoutStage[] = ['cart', 'information', 'shipping', 'payment', 'review', 'confirmation'];
    const currentIndex = stages.indexOf(checkoutInfo.stage);
    
    if (currentIndex > 0) {
      setCheckoutStage(stages[currentIndex - 1]);
    }
  };
  
  // Maneja el procesamiento del pedido
  const handleProcessOrder = async () => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const result = await processOrder();
      
      if (result.success) {
        setCheckoutStage('confirmation');
      } else {
        setError(result.message || 'Error al procesar el pedido');
      }
    } catch (err) {
      setError('Ocurrió un error inesperado');
    } finally {
      setIsProcessing(false);
    }
  };

  // Renderiza la barra de progreso del checkout
  const renderProgressBar = () => {
    const stages = [
      { key: 'information', label: 'Información' },
      { key: 'shipping', label: 'Envío' },
      { key: 'payment', label: 'Pago' },
      { key: 'review', label: 'Revisar' }
    ];
    
    const currentIndex = stages.findIndex(s => s.key === checkoutInfo.stage);
    
    return (
      <div className="w-full mb-6">
        <div className="flex justify-between mb-1">
          {stages.map((stage, index) => (
            <div key={stage.key} className="flex flex-col items-center">
              <div 
                className={`w-8 h-8 rounded-full flex items-center justify-center font-medium text-sm
                  ${index <= currentIndex 
                    ? 'bg-alien-green text-black' 
                    : 'bg-gray-800 text-gray-400'}`}
              >
                {index + 1}
              </div>
              <span className={`text-xs mt-1 ${index <= currentIndex ? 'text-white' : 'text-gray-500'}`}>
                {stage.label}
              </span>
            </div>
          ))}
        </div>
        <div className="relative w-full h-1 bg-gray-800 rounded-full mt-2">
          <motion.div 
            className="absolute h-full bg-alien-green rounded-full"
            initial={{ width: '0%' }}
            animate={{ 
              width: `${(currentIndex / (stages.length - 1)) * 100}%`,
              transition: { duration: 0.3 }
            }}
          />
        </div>
      </div>
    );
  };
  
  // Comprueba si el formulario es válido para avanzar
  const canProceed = () => {
    if (checkoutInfo.stage === 'information') {
      const { contactInfo, shippingAddress } = checkoutInfo;
      return !!(
        contactInfo.email && 
        contactInfo.firstName && 
        contactInfo.lastName && 
        shippingAddress.address1 && 
        shippingAddress.city && 
        shippingAddress.state && 
        shippingAddress.zipCode
      );
    }
    
    return true;
  };

  // Si no hay productos en el carrito, muestra mensaje
  if (items.length === 0 && checkoutInfo.stage !== 'confirmation') {
    return (
      <div className="p-6 text-center">
        <p className="text-lg text-gray-400">No hay productos en tu carrito</p>
        <Button 
          variant="tertiary"
          className="mt-4"
          onClick={() => setCheckoutStage('cart')}
        >
          Volver al carrito
        </Button>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* No mostrar en la página de confirmación */}
      {checkoutInfo.stage !== 'confirmation' && (
        <>
          {renderProgressBar()}
          
          <div className="mb-6 border-b border-gray-800 pb-4">
            <h3 className="font-medium text-lg mb-2">
              {checkoutInfo.stage === 'information' && 'Información de Contacto'}
              {checkoutInfo.stage === 'shipping' && 'Método de Envío'}
              {checkoutInfo.stage === 'payment' && 'Método de Pago'}
              {checkoutInfo.stage === 'review' && 'Revisa tu Pedido'}
            </h3>
            <p className="text-sm text-gray-400">
              {checkoutInfo.stage === 'information' && 'Completa tu información personal y de envío'}
              {checkoutInfo.stage === 'shipping' && 'Selecciona cómo quieres recibir tu pedido'}
              {checkoutInfo.stage === 'payment' && 'Elige cómo quieres pagar'}
              {checkoutInfo.stage === 'review' && 'Verifica los detalles antes de finalizar'}
            </p>
          </div>
        </>
      )}
      
      {/* Contenido específico de cada etapa */}
      <div className="mb-6">
        {checkoutInfo.stage === 'information' && <CheckoutInformation />}
        {checkoutInfo.stage === 'shipping' && <CheckoutShipping />}
        {checkoutInfo.stage === 'payment' && <CheckoutPayment />}
        {checkoutInfo.stage === 'review' && <CheckoutReview />}
        {checkoutInfo.stage === 'confirmation' && <CheckoutConfirmation />}
      </div>
      
      {/* Mostrar error si existe */}
      {error && (
        <div className="bg-red-900/30 text-red-400 p-3 rounded-md mb-4 text-sm">
          {error}
        </div>
      )}
      
      {/* Botones de navegación (no mostrar en confirmación) */}
      {checkoutInfo.stage !== 'confirmation' && (
        <div className="mt-8 space-y-3">
          {checkoutInfo.stage === 'review' ? (
            <Button 
              fullWidth
              onClick={handleProcessOrder}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <div className="flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-black border-t-transparent rounded-full mr-2"
                  />
                  <span>Procesando...</span>
                </div>
              ) : (
                'FINALIZAR COMPRA'
              )}
            </Button>
          ) : (
            <Button 
              fullWidth
              onClick={handleNext}
              disabled={!canProceed()}
            >
              CONTINUAR
            </Button>
          )}
          
          <Button 
            variant="tertiary" 
            fullWidth
            onClick={handleBack}
          >
            VOLVER
          </Button>
        </div>
      )}
      
      {/* Resumen de compra (solo para pantallas pequeñas) */}
      {checkoutInfo.stage !== 'confirmation' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8 pt-4 border-t border-gray-800"
        >
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">Subtotal</span>
            <span className="text-sm">${summary.subtotal.toLocaleString()}</span>
          </div>
          
          {summary.discount > 0 && (
            <div className="flex justify-between mb-2">
              <span className="text-alien-teal text-sm">Descuento</span>
              <span className="text-alien-teal text-sm">-${summary.discount.toLocaleString()}</span>
            </div>
          )}
          
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">Envío</span>
            <span className="text-sm">${summary.shippingCost.toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">Impuestos</span>
            <span className="text-sm">${summary.tax.toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between mt-2 pt-2 border-t border-gray-800">
            <span className="font-medium">Total</span>
            <span className="font-medium text-alien-green">${summary.total.toLocaleString()}</span>
          </div>
        </motion.div>
      )}
    </div>
  );
};