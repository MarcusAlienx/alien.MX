import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/atoms/Button';
import { CartItem } from '@/components/molecules/CartItem';
import { useCartStore } from '@/lib/store';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { 
  PromoCode, 
  ShippingMethod, 
  PaymentMethod, 
  CheckoutStage 
} from '@/lib/store';

// Importaciones para el checkout
import { Checkout } from './Checkout';
import { WishlistView } from './WishlistView';

interface ShoppingCartProps {
  className?: string;
}

// Animación para el overlay de fondo
const backdropVariants: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 }
};

// Animación para el contenedor del carrito
const cartVariants: Variants = {
  hidden: { x: '100%', opacity: 0.5 },
  visible: { 
    x: 0, 
    opacity: 1,
    transition: { 
      type: 'spring', 
      damping: 25, 
      stiffness: 300,
      duration: 0.3
    }
  },
  exit: { 
    x: '100%', 
    opacity: 0,
    transition: { duration: 0.2 }
  }
};

// Animación para los elementos de la lista
const listItemVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: (custom) => ({
    opacity: 1,
    y: 0,
    transition: { 
      delay: custom * 0.05,
      duration: 0.3,
      type: 'spring',
      stiffness: 300
    }
  }),
  removed: {
    opacity: 0,
    x: -100,
    transition: { duration: 0.2 }
  }
};

// Animación para los totales
const summaryVariants: Variants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      delay: 0.2, 
      duration: 0.3
    }
  }
};

export const ShoppingCart: React.FC<ShoppingCartProps> = ({ className }) => {
  const { 
    // Estado básico
    items, 
    isOpen, 
    lastAddedItem,
    currentView,
    wishlist,
    
    // Info de checkout
    appliedPromo,
    summary,
    checkoutInfo,
    shippingMethods,
    
    // Métodos de UI
    closeCart,
    clearCart,
    setCartView,
    
    // Métodos de checkout
    applyPromoCode,
    removePromoCode,
    calculateSummary,
    setCheckoutStage
  } = useCartStore();
  
  const [promoCode, setPromoCode] = useState('');
  const [isApplyingPromo, setIsApplyingPromo] = useState(false);
  const [promoError, setPromoError] = useState<string | null>(null);

  // Calcular totales cuando cambian los items
  useEffect(() => {
    calculateSummary();
  }, [items, calculateSummary, checkoutInfo.shippingMethod]);

  // Ir a la vista de checkout
  const handleProceedToCheckout = () => {
    setCheckoutStage('information');
    setCartView('checkout');
  };

  // Aplicar código promo
  const handleApplyPromo = async () => {
    if (!promoCode.trim()) return;
    
    setIsApplyingPromo(true);
    setPromoError(null);
    
    try {
      const success = await applyPromoCode(promoCode);
      
      if (!success && appliedPromo?.message) {
        setPromoError(appliedPromo.message);
      } else if (success) {
        setPromoCode(''); // Limpiar campo
      }
    } catch (error) {
      setPromoError('Error al aplicar el código');
    } finally {
      setIsApplyingPromo(false);
    }
  };

  // Función para obtener el título según la vista actual
  const getHeaderTitle = () => {
    switch (currentView) {
      case 'checkout':
        return 'Proceso de Compra';
      case 'wishlist':
        return 'Lista de Deseos';
      default:
        return 'Tu Carrito Espacial';
    }
  };

  // Verificar si el botón de volver debe mostrarse
  const shouldShowBackButton = () => {
    return currentView !== 'cart' || 
           (currentView === 'checkout' && checkoutInfo.stage !== 'cart');
  };

  // Volver a la vista anterior
  const handleBack = () => {
    if (currentView === 'checkout') {
      if (checkoutInfo.stage === 'information') {
        setCartView('cart');
      } else {
        // Retroceder una etapa en el checkout
        const stages: CheckoutStage[] = ['cart', 'information', 'shipping', 'payment', 'review', 'confirmation'];
        const currentIndex = stages.indexOf(checkoutInfo.stage);
        if (currentIndex > 0) {
          setCheckoutStage(stages[currentIndex - 1]);
        }
      }
    } else {
      setCartView('cart');
    }
  };

  // Renderiza la vista principal del carrito
  const renderCartView = () => (
    <>
      <AnimatePresence>
        {items.length === 0 ? (
          <motion.div 
            className="text-center py-8 flex flex-col items-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", damping: 20 }}
          >
            <motion.span 
              className="material-icons text-gray-500 text-5xl mb-4"
              animate={{ 
                y: [0, -10, 0],
                rotateZ: [0, 5, -5, 0] 
              }}
              transition={{ 
                duration: 2, 
                ease: "easeInOut", 
                repeat: Infinity,
                repeatDelay: 1
              }}
            >
              shopping_cart
            </motion.span>
            <motion.p 
              className="text-gray-400 mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              Tu carrito está vacío
            </motion.p>
            <motion.p 
              className="text-gray-500 text-sm mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              ¡Añade productos extraterrestres para comenzar!
            </motion.p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                variant="secondary"
                onClick={closeCart}
              >
                Continuar explorando
              </Button>
            </motion.div>
            
            {wishlist.length > 0 && (
              <motion.div
                className="mt-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <p className="text-sm text-gray-400 mb-2">¿Tienes productos en tu lista de deseos?</p>
                <Button 
                  variant="tertiary" 
                  size="sm"
                  onClick={() => setCartView('wishlist')}
                >
                  Ver lista de deseos ({wishlist.length})
                </Button>
              </motion.div>
            )}
          </motion.div>
        ) : (
          <>
            {/* Cart Items */}
            <motion.div 
              className="divide-y divide-gray-800"
              initial="hidden"
              animate="visible"
              exit="hidden"
            >
              <AnimatePresence>
                {items.map((item, index) => (
                  <motion.div
                    key={item.product.id}
                    custom={index}
                    variants={listItemVariants}
                    initial="hidden"
                    animate="visible"
                    exit="removed"
                    layout
                    className={cn(
                      item.product.id === lastAddedItem ? "bg-alien-green/10 rounded-lg" : ""
                    )}
                  >
                    <CartItem item={item} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>
            
            {/* Cart Summary */}
            <motion.div 
              className="mt-6 space-y-4"
              variants={summaryVariants}
              initial="hidden"
              animate="visible"
            >
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Subtotal</span>
                <motion.span
                  key={summary.subtotal}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  ${summary.subtotal.toLocaleString()}
                </motion.span>
              </div>
              
              {appliedPromo && appliedPromo.isValid && (
                <div className="flex justify-between text-sm">
                  <span className="text-alien-teal flex items-center">
                    <span className="material-icons text-sm mr-1">local_offer</span>
                    Descuento {appliedPromo.discountPercentage > 0 
                      ? `(${appliedPromo.discountPercentage}%)` 
                      : ''}
                  </span>
                  <span className="text-alien-teal">-${summary.discount.toLocaleString()}</span>
                </div>
              )}
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Envío</span>
                <span>${summary.shippingCost.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">IVA (16%)</span>
                <span>${summary.tax.toLocaleString()}</span>
              </div>
              
              <motion.div 
                className="flex justify-between font-medium pt-2 border-t border-gray-800"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <span>Total</span>
                <motion.span 
                  className="text-alien-green"
                  key={summary.total}
                  initial={{ scale: 1 }}
                  animate={{ 
                    scale: [1, 1.1, 1],
                    transition: { duration: 0.3 }
                  }}
                >
                  ${summary.total.toLocaleString()}
                </motion.span>
              </motion.div>
            </motion.div>
            
            {/* Promo Code */}
            <motion.div 
              className="mt-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              {appliedPromo && appliedPromo.isValid ? (
                <div className="bg-gray-800/60 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-alien-teal text-sm font-medium">
                        {appliedPromo.code}
                      </span>
                      <p className="text-xs text-gray-400">
                        {appliedPromo.discountPercentage > 0 
                          ? `${appliedPromo.discountPercentage}% de descuento` 
                          : `$${appliedPromo.discountAmount} de descuento`}
                      </p>
                    </div>
                    <Button 
                      variant="tertiary" 
                      size="sm"
                      onClick={removePromoCode}
                    >
                      Eliminar
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex">
                    <input 
                      type="text" 
                      placeholder="Código promocional" 
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="flex-grow px-3 py-2 bg-alien-blue border border-gray-700 rounded-l focus:outline-none focus:ring-1 focus:ring-alien-teal text-sm"
                    />
                    <motion.button 
                      className={`bg-alien-teal text-alien-dark font-medium px-4 py-2 rounded-r ${
                        isApplyingPromo ? 'opacity-70' : ''
                      }`}
                      whileHover={!isApplyingPromo ? { backgroundColor: "#4ECDC4" } : {}}
                      whileTap={!isApplyingPromo ? { scale: 0.95 } : {}}
                      onClick={handleApplyPromo}
                      disabled={isApplyingPromo}
                    >
                      {isApplyingPromo ? 'Aplicando...' : 'Aplicar'}
                    </motion.button>
                  </div>
                  {promoError && (
                    <p className="text-red-400 text-xs mt-1">{promoError}</p>
                  )}
                  
                  {/* Sugerencias de códigos */}
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    <button 
                      className="text-alien-teal hover:underline"
                      onClick={() => setPromoCode('ALIEN10')}
                    >
                      ALIEN10
                    </button>
                    <button 
                      className="text-alien-teal hover:underline"
                      onClick={() => setPromoCode('FREESHIP')}
                    >
                      FREESHIP
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
            
            {/* Checkout Buttons */}
            <motion.div 
              className="mt-6 space-y-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button 
                  fullWidth
                  onClick={handleProceedToCheckout}
                >
                  PROCEDER AL PAGO
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button 
                  variant="tertiary" 
                  fullWidth
                  onClick={closeCart}
                >
                  SEGUIR COMPRANDO
                </Button>
              </motion.div>
              
              {wishlist.length > 0 && (
                <div className="pt-2 text-center">
                  <button 
                    className="text-sm text-alien-teal hover:underline"
                    onClick={() => setCartView('wishlist')}
                  >
                    Ver lista de deseos ({wishlist.length})
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop/Overlay */}
          <motion.div
            className="fixed inset-0 bg-black/50 z-40"
            variants={backdropVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            onClick={closeCart}
          />
          
          {/* Cart Container */}
          <motion.div 
            className={cn(
              'fixed top-0 right-0 h-full w-full max-w-md bg-alien-darker shadow-lg z-50 overflow-hidden',
              className
            )}
            variants={cartVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            {/* Header */}
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <div className="flex items-center">
                {shouldShowBackButton() && (
                  <motion.button 
                    className="mr-2 text-gray-400 hover:text-white p-1"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleBack}
                  >
                    <span className="material-icons">arrow_back</span>
                  </motion.button>
                )}
                <motion.h2 
                  className="font-space font-bold text-xl"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  key={currentView}
                >
                  {getHeaderTitle()}
                </motion.h2>
              </div>
              <motion.button 
                className="text-gray-400 hover:text-white transition-colors p-1 rounded-full hover:bg-gray-800"
                whileHover={{ rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={closeCart}
              >
                <span className="material-icons">close</span>
              </motion.button>
            </div>
            
            {/* Cart Content */}
            <div className="overflow-y-auto h-[calc(100%-80px)]">
              {currentView === 'cart' && (
                <div className="p-4">
                  {renderCartView()}
                </div>
              )}
              
              {currentView === 'checkout' && (
                <Checkout />
              )}
              
              {currentView === 'wishlist' && (
                <WishlistView />
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
