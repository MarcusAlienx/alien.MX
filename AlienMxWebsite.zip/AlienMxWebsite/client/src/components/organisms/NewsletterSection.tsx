import React from 'react';
import { cn } from '@/lib/utils';
import { GradientText } from '@/components/atoms/GradientText';
import { Newsletter } from '@/components/molecules/Newsletter';
import { UfoShape } from '@/components/atoms/UfoShape';

interface NewsletterSectionProps {
  className?: string;
}

export const NewsletterSection: React.FC<NewsletterSectionProps> = ({ className }) => {
  return (
    <section className={cn(
      'py-20 bg-alien-blue relative overflow-hidden',
      className
    )}>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-10">
          <h2 className="font-space text-4xl font-bold mb-4">
            Mantente <GradientText>Conectado</GradientText>
          </h2>
          <p className="text-gray-300 mb-6">
            Suscríbete para recibir las últimas noticias sobre avistamientos, investigaciones y eventos especiales.
          </p>
        </div>
        
        <div className="max-w-2xl mx-auto">
          <Newsletter />
          <div className="text-center mt-4 text-sm text-gray-400">
            Recibirás contenido exclusivo y serás el primero en conocer nuevos avistamientos
          </div>
        </div>
      </div>
      
      {/* Background UFO elements */}
      <UfoShape 
        className="absolute -bottom-10 -left-20 w-40 h-20"
        variant="teal"
      />
      <UfoShape 
        className="absolute top-20 -right-16 w-32 h-16"
        variant="green"
      />
    </section>
  );
};
