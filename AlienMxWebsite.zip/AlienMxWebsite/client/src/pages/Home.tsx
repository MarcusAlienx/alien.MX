import React from 'react';
import { Header } from '@/components/organisms/Header';
import { Footer } from '@/components/organisms/Footer';
import { HeroSection } from '@/components/organisms/HeroSection';
import { MembershipTiers } from '@/components/organisms/MembershipTiers';
import { FeaturedProducts } from '@/components/organisms/FeaturedProducts';
import { SightingsMap } from '@/components/organisms/SightingsMap';
import { CommunitySection } from '@/components/organisms/CommunitySection';
import { LatestArticles } from '@/components/organisms/LatestArticles';
import { NewsletterSection } from '@/components/organisms/NewsletterSection';
import { ShoppingCart } from '@/components/organisms/ShoppingCart';

export const Home: React.FC = () => {
  return (
    <div className="font-sans text-gray-100 min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <HeroSection />
        <MembershipTiers />
        <FeaturedProducts />
        <SightingsMap />
        <CommunitySection />
        <LatestArticles />
        <NewsletterSection />
      </main>
      
      <Footer />
      <ShoppingCart />
    </div>
  );
};

export default Home;
