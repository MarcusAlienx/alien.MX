import React, { useState } from 'react';
import { Header } from '@/components/organisms/Header';
import { Footer } from '@/components/organisms/Footer';
import { Button } from '@/components/atoms/Button';
import { Badge } from '@/components/atoms/Badge';
import { GradientText } from '@/components/atoms/GradientText';
import { UfoShape } from '@/components/atoms/UfoShape';
import { Avatar } from '@/components/atoms/Avatar';
import { User } from '@/types';

// Mock user data
const mockUser: User & {
  memberSince: string;
  level: number;
  points: number;
  role: string;
  badges: {name: string; date: string; icon: string}[];
  stats: {label: string; value: number}[];
  sightings: number;
  contributions: number;
  achievements: {name: string; description: string; icon: string; date: string; points: number}[];
  recentActivities: {type: string; title: string; date: string; points: number}[];
} = {
  id: 1,
  username: 'CosmicExplorer',
  avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
  level: 4,
  role: 'Investigador',
  points: 2750,
  memberSince: '2023-02-15',
  badges: [
    { name: 'Observador Novato', date: '2023-02-15', icon: '🔭' },
    { name: 'Primer Avistamiento', date: '2023-03-10', icon: '🛸' },
    { name: 'Contribuidor Activo', date: '2023-05-22', icon: '🌟' },
    { name: 'Verificador', date: '2023-07-15', icon: '✅' }
  ],
  stats: [
    { label: 'Avistamientos', value: 8 },
    { label: 'Comentarios', value: 32 },
    { label: 'Verificaciones', value: 5 },
    { label: 'Artículos', value: 2 }
  ],
  sightings: 8,
  contributions: 47,
  achievements: [
    {
      name: 'Primer contacto',
      description: 'Reportaste tu primer avistamiento con evidencia fotográfica',
      icon: '📸',
      date: '2023-03-10',
      points: 250
    },
    {
      name: 'Colaborador de datos',
      description: 'Contribuiste con información valiosa a 5 investigaciones',
      icon: '📊',
      date: '2023-05-22',
      points: 500
    },
    {
      name: 'Red comunitaria',
      description: 'Conectaste con más de 20 miembros de la comunidad',
      icon: '🌐',
      date: '2023-06-30',
      points: 300
    },
    {
      name: 'Verificador de campo',
      description: 'Verificaste la autenticidad de al menos 5 avistamientos',
      icon: '🔍',
      date: '2023-07-15',
      points: 750
    }
  ],
  recentActivities: [
    {
      type: 'avistamiento',
      title: 'Reportaste "Luces en formación sobre Cuernavaca"',
      date: '2023-08-20',
      points: 150
    },
    {
      type: 'comentario',
      title: 'Comentaste en "Análisis del avistamiento de Valle de Bravo"',
      date: '2023-08-15',
      points: 10
    },
    {
      type: 'verificación',
      title: 'Verificaste el avistamiento "Objeto triangular en Monterrey"',
      date: '2023-08-10',
      points: 75
    },
    {
      type: 'artículo',
      title: 'Publicaste "Patrones de movimiento no convencionales"',
      date: '2023-08-05',
      points: 200
    }
  ]
};

// Calculate next level progress
const currentLevelThreshold = 2500; // Points needed for current level
const nextLevelThreshold = 3500;    // Points needed for next level
const progressPercentage = ((mockUser.points - currentLevelThreshold) / (nextLevelThreshold - currentLevelThreshold)) * 100;

const UserProfile: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'achievements' | 'activity' | 'settings'>('overview');
  
  return (
    <div className="font-sans text-gray-100 min-h-screen flex flex-col bg-black">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          {/* Profile Header */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 mb-8">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <Avatar 
                src={mockUser.avatar || ''}
                alt={mockUser.username}
                size="lg"
                className="ring-4 ring-alien-green/30"
              />
              
              <div className="flex-grow text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <h1 className="text-2xl font-bold">{mockUser.username}</h1>
                    <div className="flex items-center justify-center md:justify-start mt-1 space-x-2">
                      <Badge variant="analysis">Nivel {mockUser.level}</Badge>
                      <Badge variant="info">{mockUser.role}</Badge>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <Button variant="primary" size="sm">Editar perfil</Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  {mockUser.stats.map((stat, idx) => (
                    <div key={idx} className="text-center">
                      <p className="text-2xl font-semibold text-alien-teal">{stat.value}</p>
                      <p className="text-sm text-gray-400">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Level Progress */}
            <div className="mt-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-400">Nivel {mockUser.level}</span>
                <span className="text-sm text-gray-400">Nivel {mockUser.level + 1}</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-4">
                <div 
                  className="bg-gradient-to-r from-alien-green to-alien-teal h-4 rounded-full" 
                  style={{ width: `${progressPercentage}%` }}
                ></div>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs text-gray-400">{mockUser.points} puntos</span>
                <span className="text-xs text-gray-400">{nextLevelThreshold} puntos necesarios</span>
              </div>
            </div>
          </div>
          
          {/* Profile Tabs */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex p-1 bg-gray-800/90 backdrop-blur-sm rounded-xl">
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'overview' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('overview')}
              >
                Resumen
              </button>
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'achievements' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('achievements')}
              >
                Logros
              </button>
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'activity' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('activity')}
              >
                Actividad
              </button>
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'settings' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('settings')}
              >
                Ajustes
              </button>
            </div>
          </div>
          
          {/* Tab Content */}
          <div className="mb-12">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* User Info */}
                <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                  <h2 className="text-xl font-bold mb-4">Información de miembro</h2>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between py-2 border-b border-gray-800">
                      <span className="text-gray-400">Miembro desde</span>
                      <span>{new Date(mockUser.memberSince).toLocaleDateString('es-MX')}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-800">
                      <span className="text-gray-400">Total de puntos</span>
                      <span>{mockUser.points}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-800">
                      <span className="text-gray-400">Avistamientos reportados</span>
                      <span>{mockUser.sightings}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-800">
                      <span className="text-gray-400">Contribuciones totales</span>
                      <span>{mockUser.contributions}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-400">Rango actual</span>
                      <span className="text-alien-teal font-medium">{mockUser.role}</span>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="font-medium mb-3">Insignias Obtenidas</h3>
                    <div className="flex flex-wrap gap-3">
                      {mockUser.badges.map((badge, idx) => (
                        <div 
                          key={idx} 
                          className="flex items-center bg-gray-800 rounded-full py-1 px-3"
                          title={`${badge.name} - Obtenido: ${new Date(badge.date).toLocaleDateString('es-MX')}`}
                        >
                          <span className="text-lg mr-2">{badge.icon}</span>
                          <span className="text-sm">{badge.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                {/* Recent Activity */}
                <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                  <h2 className="text-xl font-bold mb-4">Actividad reciente</h2>
                  
                  <div className="space-y-4">
                    {mockUser.recentActivities.map((activity, idx) => (
                      <div key={idx} className="flex items-start p-3 rounded-lg bg-gray-800/50">
                        <div className="mr-3 mt-1">
                          {activity.type === 'avistamiento' && (
                            <span className="text-lg">🛸</span>
                          )}
                          {activity.type === 'comentario' && (
                            <span className="text-lg">💬</span>
                          )}
                          {activity.type === 'verificación' && (
                            <span className="text-lg">✅</span>
                          )}
                          {activity.type === 'artículo' && (
                            <span className="text-lg">📝</span>
                          )}
                        </div>
                        <div className="flex-grow">
                          <p className="text-sm">{activity.title}</p>
                          <div className="flex justify-between mt-1">
                            <span className="text-xs text-gray-400">
                              {new Date(activity.date).toLocaleDateString('es-MX')}
                            </span>
                            <span className="text-xs text-alien-teal">+{activity.points} pts</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6 text-center">
                    <Button variant="secondary" size="sm">
                      Ver historial completo
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'achievements' && (
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                <div className="text-center mb-8">
                  <GradientText className="text-2xl font-bold mb-2">
                    Logros y Reconocimientos
                  </GradientText>
                  <p className="text-gray-400 max-w-2xl mx-auto">
                    Estos logros reconocen tu participación y contribuciones a la comunidad de Alien.mx. 
                    Sigue participando para desbloquear más logros y subir de nivel.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {mockUser.achievements.map((achievement, idx) => (
                    <div key={idx} className="bg-gray-800/70 rounded-xl p-5 border border-gray-700">
                      <div className="flex justify-between items-start mb-4">
                        <div className="bg-gray-900 rounded-full p-3 text-2xl">
                          {achievement.icon}
                        </div>
                        <span className="text-alien-teal text-sm font-medium">+{achievement.points} pts</span>
                      </div>
                      <h3 className="font-bold text-lg mb-1">{achievement.name}</h3>
                      <p className="text-sm text-gray-300 mb-3">{achievement.description}</p>
                      <div className="text-xs text-gray-400">
                        Obtenido: {new Date(achievement.date).toLocaleDateString('es-MX')}
                      </div>
                    </div>
                  ))}
                  
                  {/* Locked achievements */}
                  {[...Array(3)].map((_, idx) => (
                    <div key={`locked-${idx}`} className="bg-gray-800/40 rounded-xl p-5 border border-gray-700/40 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gray-900/70 flex items-center justify-center">
                        <div className="text-center p-4">
                          <span className="text-2xl block mb-2">🔒</span>
                          <span className="text-gray-400">Logro bloqueado</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-start mb-4">
                        <div className="bg-gray-900 rounded-full p-3 text-2xl">
                          ?
                        </div>
                        <span className="text-gray-500 text-sm font-medium">+??? pts</span>
                      </div>
                      <h3 className="font-bold text-lg mb-1">???</h3>
                      <p className="text-sm text-gray-600 mb-3">Sigue participando para desbloquear este logro</p>
                      <div className="text-xs text-gray-500">
                        Pendiente
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-10 mb-4">
                  <h3 className="text-lg font-bold mb-4">Niveles y recompensas</h3>
                  <div className="space-y-6">
                    {[...Array(7)].map((_, idx) => {
                      const level = idx + 1;
                      const isCurrentLevel = level === mockUser.level;
                      const isCompleted = level < mockUser.level;
                      
                      return (
                        <div 
                          key={`level-${level}`} 
                          className={`relative pl-8 pb-6 ${idx < 6 ? 'border-l-2' : ''} ${
                            isCompleted ? 'border-alien-teal' : 'border-gray-700'
                          }`}
                        >
                          <div 
                            className={`absolute left-[-9px] top-0 w-4 h-4 rounded-full ${
                              isCompleted ? 'bg-alien-teal' : 
                              isCurrentLevel ? 'bg-alien-green animate-pulse' : 'bg-gray-700'
                            }`}
                          ></div>
                          <div className={isCurrentLevel ? 'text-white' : isCompleted ? 'text-gray-300' : 'text-gray-500'}>
                            <h4 className="font-bold">
                              Nivel {level} - {
                                level === 1 ? 'Observador' : 
                                level === 2 ? 'Informante' : 
                                level === 3 ? 'Colaborador' : 
                                level === 4 ? 'Investigador' : 
                                level === 5 ? 'Analista' : 
                                level === 6 ? 'Experto' : 'Maestro'
                              }
                            </h4>
                            <p className="text-sm mt-1">
                              {level === 1 
                                ? 'Acceso a reportes de avistamientos básicos y foros de discusión.' 
                                : level === 2 
                                  ? 'Desbloquea la capacidad de comentar en reportes y artículos.'
                                  : level === 3
                                    ? 'Permite reportar avistamientos con evidencia multimedia.'
                                    : level === 4
                                      ? 'Acceso a herramientas de análisis y verificación de reportes.'
                                      : level === 5
                                        ? 'Capacidad para publicar artículos y crear expedientes de investigación.'
                                        : level === 6
                                          ? 'Acceso a datos históricos completos y herramientas avanzadas de análisis.'
                                          : 'Participación en investigaciones especiales y eventos exclusivos.'
                              }
                            </p>
                            {isCurrentLevel && (
                              <div className="mt-2 text-xs font-medium text-alien-teal">
                                Tu nivel actual • {nextLevelThreshold - mockUser.points} puntos para el siguiente nivel
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'activity' && (
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold">Historial de actividad</h2>
                  <div className="flex gap-2">
                    <select className="bg-gray-800 border border-gray-700 rounded-lg py-1 px-3 text-white text-sm">
                      <option>Todos los tipos</option>
                      <option>Avistamientos</option>
                      <option>Comentarios</option>
                      <option>Verificaciones</option>
                      <option>Artículos</option>
                    </select>
                    <select className="bg-gray-800 border border-gray-700 rounded-lg py-1 px-3 text-white text-sm">
                      <option>Últimos 30 días</option>
                      <option>Últimos 90 días</option>
                      <option>Este año</option>
                      <option>Todo el tiempo</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-6">
                  {/* Activity by month sections */}
                  {['Agosto 2023', 'Julio 2023', 'Junio 2023'].map((month, monthIdx) => (
                    <div key={month} className="mb-8">
                      <h3 className="text-lg font-medium text-alien-teal mb-4">{month}</h3>
                      
                      <div className="space-y-3">
                        {/* Generate more activities than the recent ones */}
                        {[...Array(monthIdx === 0 ? 6 : 4)].map((_, idx) => {
                          // Use recent activities for the first month, then generate variations
                          const activity = monthIdx === 0 && idx < mockUser.recentActivities.length 
                            ? mockUser.recentActivities[idx]
                            : {
                                type: ['avistamiento', 'comentario', 'verificación', 'artículo'][(idx + monthIdx) % 4],
                                title: [
                                  'Reportaste "Objeto con luces en Puebla"',
                                  'Comentaste en "Análisis de patrones de vuelo"',
                                  'Verificaste el avistamiento "Formación en V sobre Guadalajara"',
                                  'Publicaste "Características de los orbes luminosos"'
                                ][(idx + monthIdx) % 4],
                                date: `2023-0${8 - monthIdx}-${20 - idx - (monthIdx * 5)}`,
                                points: [150, 10, 75, 200][(idx + monthIdx) % 4]
                              };
                          
                          return (
                            <div key={`${month}-${idx}`} className="flex items-start p-3 rounded-lg bg-gray-800/50">
                              <div className="mr-3 mt-1">
                                {activity.type === 'avistamiento' && (
                                  <span className="text-lg">🛸</span>
                                )}
                                {activity.type === 'comentario' && (
                                  <span className="text-lg">💬</span>
                                )}
                                {activity.type === 'verificación' && (
                                  <span className="text-lg">✅</span>
                                )}
                                {activity.type === 'artículo' && (
                                  <span className="text-lg">📝</span>
                                )}
                              </div>
                              <div className="flex-grow">
                                <p className="text-sm">{activity.title}</p>
                                <div className="flex justify-between mt-1">
                                  <span className="text-xs text-gray-400">
                                    {new Date(activity.date).toLocaleDateString('es-MX')}
                                  </span>
                                  <span className="text-xs text-alien-teal">+{activity.points} pts</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 text-center">
                  <Button variant="secondary">
                    Cargar más actividad
                  </Button>
                </div>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                <UfoShape className="mx-auto mb-6" glow>
                  <h2 className="text-center text-xl font-bold">Ajustes de cuenta</h2>
                </UfoShape>
                
                <div className="max-w-2xl mx-auto">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Información personal</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Nombre de usuario</label>
                          <input 
                            type="text" 
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                            defaultValue={mockUser.username}
                          />
                        </div>
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Email</label>
                          <input 
                            type="email" 
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                            defaultValue="usuario@ejemplo.com"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Cambiar contraseña</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Contraseña actual</label>
                          <input 
                            type="password" 
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Nueva contraseña</label>
                          <input 
                            type="password" 
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-sm text-gray-400 mb-1">Confirmar nueva contraseña</label>
                          <input 
                            type="password" 
                            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Notificaciones</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <div>
                            <h4 className="font-medium">Notificaciones por email</h4>
                            <p className="text-sm text-gray-400">Recibe actualizaciones de la comunidad por correo</p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-alien-teal"></div>
                          </label>
                        </div>
                        
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <div>
                            <h4 className="font-medium">Notificaciones de nuevos avistamientos</h4>
                            <p className="text-sm text-gray-400">Avisos sobre nuevos reportes en tu área</p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-alien-teal"></div>
                          </label>
                        </div>
                        
                        <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <div>
                            <h4 className="font-medium">Notificaciones de la tienda</h4>
                            <p className="text-sm text-gray-400">Actualizaciones sobre nuevos productos y ofertas</p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" />
                            <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-alien-teal"></div>
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-800 pt-6">
                      <div className="flex justify-end">
                        <Button variant="secondary" className="mr-3">
                          Cancelar
                        </Button>
                        <Button variant="primary">
                          Guardar cambios
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default UserProfile;