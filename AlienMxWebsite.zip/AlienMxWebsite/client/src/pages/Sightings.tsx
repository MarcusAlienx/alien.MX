import React, { useState } from 'react';
import { Header } from '@/components/organisms/Header';
import { Footer } from '@/components/organisms/Footer';
import { Button } from '@/components/atoms/Button';
import { Badge } from '@/components/atoms/Badge';
import { GradientText } from '@/components/atoms/GradientText';
import { UfoShape } from '@/components/atoms/UfoShape';
import { StarsBackground } from '@/components/atoms/StarsBackground';
import { SightingLocation } from '@/types';

const mockSightings: SightingLocation[] = [
  {
    id: 1,
    name: 'Avistamiento en Sierra de Guadalupe',
    description: 'Objeto triangular con luces pulsantes en formación estática durante 15 minutos.',
    date: '2023-08-15',
    lat: 19.5431,
    lng: -99.0802,
    type: 'verified',
    witnesses: 12
  },
  {
    id: 2,
    name: 'Luces sobre Valle de Bravo',
    description: 'Secuencia de luces anaranjadas moviéndose en patrones no lineales.',
    date: '2023-07-22',
    lat: 19.1926,
    lng: -100.1304,
    type: 'recent',
    witnesses: 8
  },
  {
    id: 3,
    name: 'Disco plateado en Monterrey',
    description: 'Objeto metálico inmóvil a gran altura fotografiado por múltiples testigos.',
    date: '2023-06-05',
    lat: 25.6866,
    lng: -100.3161,
    type: 'investigation',
    witnesses: 23
  },
  {
    id: 4,
    name: 'Formación en V sobre Puebla',
    description: 'Cinco luces dispuestas en formación V perfecta atravesando el cielo nocturno.',
    date: '2023-05-17',
    lat: 19.0414,
    lng: -98.2063,
    type: 'verified',
    witnesses: 45
  },
  {
    id: 5,
    name: 'Destellos sobre la Basílica',
    description: 'Serie de destellos multicolores estacionarios sobre la Basílica de Guadalupe.',
    date: '2023-04-12',
    lat: 19.4853,
    lng: -99.1171,
    type: 'recent',
    witnesses: 17
  }
];

const sightingStats = [
  { label: 'Avistamientos Totales', value: '2,458', color: 'text-alien-teal' },
  { label: 'Verificados', value: '876', color: 'text-green-400' },
  { label: 'En Investigación', value: '342', color: 'text-amber-400' },
  { label: 'Reportados este mes', value: '67', color: 'text-alien-pink' }
];

const SightingCard: React.FC<{ sighting: SightingLocation, onClick: () => void }> = ({ sighting, onClick }) => {
  return (
    <div 
      className="bg-gray-900/70 backdrop-blur-sm rounded-xl overflow-hidden border border-gray-800 hover:border-alien-teal transition-all cursor-pointer"
      onClick={onClick}
    >
      <div className="h-40 bg-gray-800 relative">
        <img 
          src={`https://source.unsplash.com/random/800x600?sky,night,space&sig=${sighting.id}`} 
          alt={sighting.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <Badge 
            variant={
              sighting.type === 'verified' ? 'analysis' : 
              sighting.type === 'recent' ? 'new' : 'event'
            }
          >
            {sighting.type === 'verified' ? 'Verificado' : 
             sighting.type === 'recent' ? 'Reciente' : 'En Investigación'}
          </Badge>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2 text-white">{sighting.name}</h3>
        <p className="text-gray-300 text-sm mb-3 line-clamp-2">{sighting.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-400">
            {new Date(sighting.date).toLocaleDateString('es-MX', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </span>
          <span className="text-xs bg-gray-800 text-gray-300 py-1 px-2 rounded-full">
            {sighting.witnesses} testigos
          </span>
        </div>
      </div>
    </div>
  );
};

export const Sightings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'map' | 'list' | 'report'>('map');
  const [selectedSighting, setSelectedSighting] = useState<SightingLocation | null>(null);
  
  const handleSelectSighting = (sighting: SightingLocation) => {
    setSelectedSighting(sighting);
  };

  return (
    <div className="font-sans text-gray-100 min-h-screen flex flex-col bg-black">
      <Header />
      
      <main className="flex-grow relative">
        <StarsBackground className="absolute inset-0" />
        
        <div className="container mx-auto px-4 py-8 relative z-10">
          <div className="text-center mb-12">
            <GradientText className="text-4xl font-bold mb-3">
              Mapa de Avistamientos
            </GradientText>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Explora la base de datos colaborativa de avistamientos reportados por nuestra 
              comunidad. Filtra por ubicación, fecha y tipo, o contribuye con tus propias experiencias.
            </p>
          </div>
          
          {/* Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            {sightingStats.map((stat, idx) => (
              <div key={idx} className="bg-gray-900/60 backdrop-blur-sm rounded-xl p-4 text-center">
                <p className={`text-3xl font-bold mb-1 ${stat.color}`}>{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            ))}
          </div>
          
          {/* Tabs */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex p-1 bg-gray-800/90 backdrop-blur-sm rounded-xl">
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'map' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('map')}
              >
                Mapa
              </button>
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'list' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('list')}
              >
                Listado
              </button>
              <button 
                className={`px-6 py-2 rounded-lg text-sm font-medium ${
                  activeTab === 'report' ? 'bg-alien-green/20 text-alien-green' : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setActiveTab('report')}
              >
                Reportar
              </button>
            </div>
          </div>
          
          {/* Tab Content */}
          <div className="mb-16">
            {activeTab === 'map' && (
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl overflow-hidden p-0">
                <div className="h-[600px] relative">
                  {/* Mapa simulado */}
                  <div className="absolute inset-0 bg-gray-800">
                    <img 
                      src="https://images.unsplash.com/photo-1612178537253-bccd437b730e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                      alt="Mapa de avistamientos" 
                      className="w-full h-full object-cover opacity-60"
                    />
                    
                    {/* Marcadores de avistamientos */}
                    {mockSightings.map((sighting) => (
                      <div 
                        key={sighting.id} 
                        className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
                        style={{ 
                          top: `${Math.random() * 70 + 15}%`, 
                          left: `${Math.random() * 70 + 15}%` 
                        }}
                        onClick={() => handleSelectSighting(sighting)}
                      >
                        <div className={`
                          w-4 h-4 rounded-full animate-pulse 
                          ${sighting.type === 'verified' ? 'bg-green-500' : 
                            sighting.type === 'recent' ? 'bg-blue-500' : 'bg-amber-500'}
                        `}></div>
                        <div className="absolute bottom-full mb-1 whitespace-nowrap bg-gray-900/90 text-xs px-2 py-1 rounded">
                          {sighting.name}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Sidebar con información del avistamiento seleccionado */}
                  {selectedSighting && (
                    <div className="absolute top-4 right-4 w-80 bg-gray-900/90 backdrop-blur-sm rounded-xl p-4 border border-gray-700">
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="font-bold text-lg">{selectedSighting.name}</h3>
                        <Badge 
                          variant={
                            selectedSighting.type === 'verified' ? 'analysis' : 
                            selectedSighting.type === 'recent' ? 'new' : 'event'
                          }
                        >
                          {selectedSighting.type === 'verified' ? 'Verificado' : 
                           selectedSighting.type === 'recent' ? 'Reciente' : 'En Investigación'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-300 mb-3">{selectedSighting.description}</p>
                      <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
                        <div>
                          <span className="text-gray-400 block">Fecha:</span>
                          <span>{new Date(selectedSighting.date).toLocaleDateString('es-MX')}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">Testigos:</span>
                          <span>{selectedSighting.witnesses}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">Latitud:</span>
                          <span>{selectedSighting.lat.toFixed(4)}</span>
                        </div>
                        <div>
                          <span className="text-gray-400 block">Longitud:</span>
                          <span>{selectedSighting.lng.toFixed(4)}</span>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <Button variant="secondary" size="sm">Ver detalles</Button>
                        <Button variant="primary" size="sm">Ver evidencia</Button>
                      </div>
                      <button 
                        className="absolute top-2 right-2 text-gray-400 hover:text-white"
                        onClick={() => setSelectedSighting(null)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="p-4 border-t border-gray-800">
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
                        <span className="text-sm text-gray-300">Verificados</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
                        <span className="text-sm text-gray-300">Recientes</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 rounded-full bg-amber-500 mr-2"></span>
                        <span className="text-sm text-gray-300">En investigación</span>
                      </div>
                    </div>
                    <Button variant="primary" size="sm" onClick={() => setActiveTab('report')}>
                      Reportar avistamiento
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'list' && (
              <div className="space-y-6">
                <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                  <h2 className="text-xl font-bold mb-4">Filtrar avistamientos</h2>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">Región</label>
                      <select className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white">
                        <option>Todos</option>
                        <option>Centro</option>
                        <option>Norte</option>
                        <option>Sur</option>
                        <option>Este</option>
                        <option>Oeste</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">Tipo</label>
                      <select className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white">
                        <option>Todos</option>
                        <option>Verificados</option>
                        <option>Recientes</option>
                        <option>En investigación</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">Fecha desde</label>
                      <input 
                        type="date" 
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">Fecha hasta</label>
                      <input 
                        type="date" 
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-white"
                      />
                    </div>
                  </div>
                  <div className="mt-4 flex justify-end">
                    <Button variant="secondary" size="sm" className="mr-2">
                      Limpiar filtros
                    </Button>
                    <Button variant="primary" size="sm">
                      Aplicar filtros
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {mockSightings.map((sighting) => (
                    <SightingCard 
                      key={sighting.id} 
                      sighting={sighting} 
                      onClick={() => {
                        setSelectedSighting(sighting);
                        setActiveTab('map');
                      }}
                    />
                  ))}
                </div>
                
                <div className="flex justify-center mt-8">
                  <Button variant="secondary">
                    Cargar más avistamientos
                  </Button>
                </div>
              </div>
            )}
            
            {activeTab === 'report' && (
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6">
                <UfoShape className="mx-auto mb-6" glow>
                  <h2 className="text-center text-xl font-bold">Reportar nuevo avistamiento</h2>
                </UfoShape>
                
                <p className="text-gray-300 text-center max-w-xl mx-auto mb-8">
                  Tus reportes ayudan a la comunidad a mapear e investigar fenómenos en todo el país. 
                  Por favor incluye tantos detalles como sea posible, incluyendo imágenes o videos si los tienes.
                </p>
                
                <form className="max-w-2xl mx-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Título del avistamiento*
                      </label>
                      <input 
                        type="text" 
                        className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white"
                        placeholder="Ej. Luces en formación sobre Coyoacán"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Fecha y hora*
                      </label>
                      <input 
                        type="datetime-local" 
                        className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Ubicación*
                      </label>
                      <input 
                        type="text" 
                        className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white"
                        placeholder="Ej. Coyoacán, Ciudad de México"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Número de testigos
                      </label>
                      <input 
                        type="number" 
                        min="1"
                        className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white"
                        placeholder="Ej. 3"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Descripción detallada*
                      </label>
                      <textarea 
                        className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white min-h-[120px]"
                        placeholder="Describe lo que viste con el mayor detalle posible. Incluye información sobre forma, color, movimiento, sonido, duración, etc."
                        required
                      ></textarea>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Tipo de objeto/fenómeno
                      </label>
                      <select className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white">
                        <option value="">Selecciona una opción</option>
                        <option>Luces en el cielo</option>
                        <option>Objeto sólido</option>
                        <option>Formación de objetos</option>
                        <option>Objeto con cambio de forma</option>
                        <option>Aterrizaje</option>
                        <option>Otro</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Duración aproximada
                      </label>
                      <select className="w-full bg-gray-800/90 border border-gray-700 rounded-lg py-2 px-3 text-white">
                        <option value="">Selecciona una opción</option>
                        <option>Menos de 1 minuto</option>
                        <option>1-5 minutos</option>
                        <option>5-15 minutos</option>
                        <option>15-30 minutos</option>
                        <option>30-60 minutos</option>
                        <option>Más de 1 hora</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Evidencia (imágenes/videos)
                      </label>
                      <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                        <p className="mt-2 text-sm text-gray-400">
                          Arrastra archivos aquí o <span className="text-alien-teal">haz clic para seleccionar</span>
                        </p>
                        <p className="mt-1 text-xs text-gray-500">
                          Formatos aceptados: JPG, PNG, GIF, MP4 (máx. 20MB por archivo)
                        </p>
                        <input type="file" className="hidden" multiple accept="image/*,video/*" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-800 pt-6">
                    <div className="flex items-start mb-6">
                      <div className="flex items-center h-5">
                        <input
                          id="terms"
                          type="checkbox"
                          className="w-4 h-4 rounded"
                          required
                        />
                      </div>
                      <label htmlFor="terms" className="ml-2 text-sm text-gray-400">
                        Confirmo que este reporte es verídico y autorizo a Alien.mx a utilizarlo 
                        en sus investigaciones y publicaciones con los datos de contacto anonimizados.
                      </label>
                    </div>
                    
                    <div className="flex justify-center">
                      <Button variant="secondary" className="mr-4">
                        Cancelar
                      </Button>
                      <Button variant="primary">
                        Enviar reporte
                      </Button>
                    </div>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Sightings;