import React, { useState } from 'react';
import { useRoute } from 'wouter';
import { Header } from '@/components/organisms/Header';
import { Footer } from '@/components/organisms/Footer';
import { Button } from '@/components/atoms/Button';
import { Badge } from '@/components/atoms/Badge';
import { Rating } from '@/components/atoms/Rating';
import { ShoppingCart } from '@/components/organisms/ShoppingCart';
import { FeaturedProducts } from '@/components/organisms/FeaturedProducts';
import { GradientText } from '@/components/atoms/GradientText';
import { UfoShape } from '@/components/atoms/UfoShape';
import { AddToCartButton } from '@/components/molecules/AddToCartButton';
import { useCartStore } from '@/lib/store';
import { Product } from '@/types';

const mockProduct: Product = {
  id: 1,
  name: 'Telescopio Avanzado UV-X5',
  description: 'Telescopio de alta potencia diseñado específicamente para detectar y capturar señales en el espectro ultravioleta e infrarrojo extremo. Perfecto para observación de fenómenos anómalos en el cielo nocturno y detección de actividad no convencional.',
  price: 599.99,
  originalPrice: 799.99,
  image: 'https://images.unsplash.com/photo-1518536846289-7b43e92c786c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
  rating: 4.8,
  reviews: 56,
  badge: 'limited',
  isNew: false,
  isPopular: true,
  isLimitedStock: true
};

const additionalImages = [
  'https://images.unsplash.com/photo-1567653418876-5bb0e566e1c2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2064&q=80',
  'https://images.unsplash.com/photo-1532944426343-7101ebb67786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80',
  'https://images.unsplash.com/photo-1547700055-b61cacebece9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
];

const specs = [
  { label: 'Aumento', value: '200x-1500x' },
  { label: 'Apertura', value: '130mm' },
  { label: 'Longitud focal', value: '650mm' },
  { label: 'Tipo', value: 'Reflector Newtoniano' },
  { label: 'Montura', value: 'Ecuatorial Computerizada' },
  { label: 'Filtros', value: 'UV, IR, Contaminación lumínica' },
  { label: 'Seguimiento', value: 'Automático Celestial' },
  { label: 'Conectividad', value: 'WiFi, Bluetooth, USB-C' },
  { label: 'App compatible', value: 'iOS, Android, Windows' }
];

export const ProductDetail: React.FC = () => {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(mockProduct.image);
  const [, params] = useRoute('/product/:id');

  const handleIncrement = () => {
    setQuantity(prev => prev + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <div className="font-sans text-gray-100 min-h-screen flex flex-col bg-black">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="overflow-hidden rounded-lg bg-black/30 aspect-square flex items-center justify-center">
                <img 
                  src={selectedImage} 
                  alt={mockProduct.name} 
                  className="object-contain h-full w-full" 
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[mockProduct.image, ...additionalImages].map((img, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`overflow-hidden rounded-md aspect-square bg-black/30 
                      ${selectedImage === img ? 'ring-2 ring-alien-green' : ''}`}
                  >
                    <img 
                      src={img} 
                      alt={`${mockProduct.name} view ${idx + 1}`} 
                      className="object-cover h-full w-full" 
                    />
                  </button>
                ))}
              </div>
            </div>
            
            {/* Product Info */}
            <div className="space-y-6">
              <div>
                {mockProduct.badge && (
                  <Badge variant={mockProduct.badge} className="mb-3">
                    {mockProduct.badge === 'new' ? 'Nuevo' : 
                     mockProduct.badge === 'popular' ? 'Popular' : 
                     mockProduct.badge === 'limited' ? 'Edición Limitada' : 
                     mockProduct.badge === 'sale' ? 'Oferta' : ''}
                  </Badge>
                )}
                <h1 className="text-3xl font-bold">{mockProduct.name}</h1>
                <div className="flex items-center mt-2">
                  <Rating value={mockProduct.rating} reviewCount={mockProduct.reviews} />
                </div>
                
                <div className="flex items-center mt-4">
                  <span className="text-3xl font-bold text-white">
                    ${mockProduct.price.toFixed(2)}
                  </span>
                  {mockProduct.originalPrice && (
                    <span className="ml-3 text-lg text-gray-400 line-through">
                      ${mockProduct.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>

              <div className="prose prose-invert max-w-none">
                <p>{mockProduct.description}</p>
              </div>
              
              {/* Quantity Selector */}
              <div className="flex items-center space-x-4">
                <span className="text-gray-300">Cantidad:</span>
                <div className="flex items-center">
                  <button 
                    onClick={handleDecrement}
                    className="w-10 h-10 rounded-l-md bg-gray-800 flex items-center justify-center hover:bg-gray-700"
                  >
                    <span className="text-xl">-</span>
                  </button>
                  <span className="w-12 h-10 bg-gray-800 flex items-center justify-center border-x border-gray-700">
                    {quantity}
                  </span>
                  <button 
                    onClick={handleIncrement}
                    className="w-10 h-10 rounded-r-md bg-gray-800 flex items-center justify-center hover:bg-gray-700"
                  >
                    <span className="text-xl">+</span>
                  </button>
                </div>
              </div>
              
              {/* Add to Cart Button */}
              <div className="pt-4">
                <AddToCartButton
                  product={mockProduct}
                  quantity={quantity}
                  fullWidth
                  showQuantity={false}
                  variant="primary"
                  className="text-lg py-3 rounded-xl"
                />
              </div>

              {/* Stock Status */}
              {mockProduct.isLimitedStock && (
                <div className="flex items-center text-amber-400">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                  </svg>
                  <span>Stock Limitado - Quedan pocas unidades</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 mb-12">
          <div className="mb-6">
            <UfoShape className="mb-4" glow>
              <h2 className="text-center text-xl font-bold">Detalles del Producto</h2>
            </UfoShape>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="prose prose-invert max-w-none">
              <h3 className="text-xl font-semibold mb-4 text-alien-green">Descripción</h3>
              <p>
                El Telescopio Avanzado UV-X5 representa lo último en tecnología de observación astronómica, específicamente optimizado para la detección de anomalías celestes. A diferencia de los telescopios convencionales, el UV-X5 incorpora sensores de espectro ultravioleta e infrarrojo que permiten captar fenómenos invisibles al ojo humano.
              </p>
              <p>
                Su sistema de tracking basado en IA puede identificar y seguir automáticamente objetos con patrones de movimiento no convencionales, registrando datos completos de trayectoria, velocidad y alteraciones electromagnéticas. La carcasa de aleación de titanio y carbono proporciona resistencia a interferencias externas.
              </p>
              <p>
                El kit incluye conectividad en tiempo real con la base de datos central de Alien.mx, permitiéndote contribuir y verificar avistamientos con la comunidad global de observadores. Compatible con nuestros filtros especializados para condiciones atmosféricas adversas.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4 text-alien-teal">Especificaciones</h3>
              <div className="grid grid-cols-1 gap-y-3">
                {specs.map((spec, idx) => (
                  <div key={idx} className="flex border-b border-gray-700 pb-2">
                    <span className="w-2/5 text-gray-400">{spec.label}:</span>
                    <span className="w-3/5 font-medium">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 mb-12">
          <div className="mb-8">
            <GradientText className="text-2xl font-bold">
              Reseñas de Usuarios
            </GradientText>
            <div className="flex items-center mt-2">
              <Rating value={mockProduct.rating} size="lg" reviewCount={mockProduct.reviews} />
            </div>
          </div>
          
          <div className="space-y-6">
            {[...Array(3)].map((_, idx) => (
              <div key={idx} className="border-b border-gray-700 pb-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start">
                    <img 
                      src={`https://randomuser.me/api/portraits/${idx % 2 ? 'women' : 'men'}/${idx + 15}.jpg`} 
                      alt="Usuario" 
                      className="w-10 h-10 rounded-full mr-3" 
                    />
                    <div>
                      <h4 className="font-medium">
                        {idx === 0 ? 'Elena García' : idx === 1 ? 'Adrián Méndez' : 'Carlos Jiménez'}
                      </h4>
                      <span className="text-sm text-gray-400">
                        {idx === 0 ? '15 julio, 2023' : idx === 1 ? '2 agosto, 2023' : '28 junio, 2023'}
                      </span>
                    </div>
                  </div>
                  <Rating value={idx === 0 ? 5 : idx === 1 ? 4 : 5} size="sm" />
                </div>
                <p className="text-gray-200">
                  {idx === 0 
                    ? "Increíble tecnología. He podido captar objetos que con mi telescopio anterior eran imposibles de ver. La integración con la app es perfecta y la comunidad me ha ayudado a verificar dos avistamientos. Vale cada centavo." 
                    : idx === 1 
                      ? "Excelente equipo, aunque el manual podría ser más claro con la calibración inicial. Una vez configurado funciona de maravilla. La calidad de construcción es impresionante y los filtros especiales son un game-changer." 
                      : "Llevo años estudiando fenómenos celestes y este telescopio ha revolucionado mi metodología. Los sensores UV captan anomalías que otros telescopios pasan por alto. El soporte técnico de Alien.mx siempre responde rápido a consultas."}
                </p>
              </div>
            ))}
          </div>
          
          <div className="mt-8 text-center">
            <Button variant="secondary">
              Ver Todas las Reseñas
            </Button>
          </div>
        </div>

        {/* Related Products */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <GradientText className="text-2xl font-bold mb-2">
              Productos relacionados
            </GradientText>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Equipos y accesorios complementarios para mejorar tu experiencia de observación
            </p>
          </div>
          
          <FeaturedProducts />
        </div>
      </main>
      
      <Footer />
      <ShoppingCart />
    </div>
  );
};

export default ProductDetail;