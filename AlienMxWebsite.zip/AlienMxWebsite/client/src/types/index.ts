// Atomic Types
export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'icon';
export type ButtonSize = 'sm' | 'md' | 'lg';
export type BadgeVariant = 'new' | 'popular' | 'limited' | 'sale' | 'info' | 'event' | 'analysis' | 'sighting';
export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg';

// Models
export interface User {
  id: number;
  username: string;
  avatar?: string;
  level?: number;
  role?: string;
  points?: number;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  badge?: BadgeVariant;
  isNew?: boolean;
  isPopular?: boolean;
  isLimitedStock?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface MembershipTier {
  id: number;
  name: string;
  description: string;
  price: number;
  icon: string;
  features: string[];
  isPopular?: boolean;
  gradient: {
    from: string;
    to: string;
  };
  buttonGradient: {
    from: string;
    to: string;
  };
}

export interface Article {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  category: string;
  date: string;
  author: User;
  views: number;
  comments: number;
}

export interface ForumPost {
  id: number;
  title: string;
  content: string;
  author: User;
  timestamp: string;
  comments: number;
  category: string;
}

export interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  buttonText?: string;
  buttonVariant?: 'reminder' | 'spots';
}

export interface SightingLocation {
  id: number;
  name: string;
  description: string;
  date: string;
  lat: number;
  lng: number;
  type: 'recent' | 'verified' | 'investigation';
  witnesses?: number;
}

export interface SightingStat {
  label: string;
  value: string | number;
  color?: string;
}
