import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, CartItem } from '@/types';

export type ShippingMethod = {
  id: string;
  name: string;
  description: string;
  price: number;
  estimatedDays: string;
};

export type PaymentMethod = 'credit_card' | 'paypal' | 'crypto' | 'bank_transfer';

export type PromoCode = {
  code: string;
  discountPercentage: number;
  discountAmount: number;
  minPurchase?: number;
  expiresAt?: Date;
  isValid: boolean;
  message?: string;
};

export type CartSummary = {
  subtotal: number;
  shippingCost: number;
  discount: number;
  tax: number;
  total: number;
};

export type CheckoutStage = 'cart' | 'information' | 'shipping' | 'payment' | 'review' | 'confirmation';

export type CheckoutInfo = {
  stage: CheckoutStage;
  contactInfo: {
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
  };
  shippingAddress: {
    address1: string;
    address2?: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  billingAddress: {
    sameAsShipping: boolean;
    address1?: string;
    address2?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
  shippingMethod?: string;
  paymentMethod?: PaymentMethod;
  orderNotes?: string;
};

interface CartState {
  // Datos básicos
  items: CartItem[];
  isOpen: boolean;
  wishlist: number[]; // IDs de productos en lista de deseos
  lastAddedItem: number | null;
  
  // Información del checkout
  appliedPromo: PromoCode | null;
  checkoutInfo: CheckoutInfo;
  shippingMethods: ShippingMethod[];
  summary: CartSummary;
  
  // Estado UI
  currentView: 'cart' | 'checkout' | 'wishlist';
  
  // Métodos para manipular ítems
  addItem: (product: Product, quantity?: number) => void;
  removeItem: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  
  // Métodos para la interfaz del carrito
  toggleCart: () => void;
  closeCart: () => void;
  openCart: () => void;
  setCartView: (view: 'cart' | 'checkout' | 'wishlist') => void;
  
  // Métodos de lista de deseos
  addToWishlist: (productId: number) => void;
  removeFromWishlist: (productId: number) => void;
  moveToCart: (productId: number, quantity?: number) => void;
  
  // Métodos para checkout
  applyPromoCode: (code: string) => Promise<boolean>;
  removePromoCode: () => void;
  setCheckoutStage: (stage: CheckoutStage) => void;
  updateCheckoutInfo: (info: Partial<CheckoutInfo>) => void;
  selectShippingMethod: (methodId: string) => void;
  calculateSummary: () => void;
  processOrder: () => Promise<{ success: boolean; orderId?: string; message?: string }>;
}

// Métodos de ayuda para cálculos
const calculateSubtotal = (items: CartItem[]): number => {
  return items.reduce((total, item) => total + (item.product.price * item.quantity), 0);
};

const calculateShipping = (items: CartItem[], shippingMethodId?: string, shippingMethods?: ShippingMethod[]): number => {
  // Si no hay items o métodos de envío, el costo es 0
  if (items.length === 0 || !shippingMethods?.length) return 0;
  
  // Si no hay método seleccionado, usar el más barato disponible
  if (!shippingMethodId && shippingMethods?.length) {
    return Math.min(...shippingMethods.map(method => method.price));
  }
  
  // Si hay método seleccionado, usarlo
  const selectedMethod = shippingMethods?.find(method => method.id === shippingMethodId);
  return selectedMethod?.price || 0;
};

const calculateDiscount = (subtotal: number, promo: PromoCode | null): number => {
  if (!promo || !promo.isValid) return 0;
  
  if (promo.discountPercentage > 0) {
    return subtotal * (promo.discountPercentage / 100);
  }
  
  return Math.min(promo.discountAmount, subtotal); // No descontar más que el subtotal
};

const calculateTax = (subtotal: number, discount: number): number => {
  // Aplicamos un IVA del 16% al subtotal después de descuentos
  return (subtotal - discount) * 0.16;
};

// Métodos de validación de promociones
const validatePromoCode = async (code: string): Promise<PromoCode> => {
  // Aquí iría una llamada a la API para validar el código
  // Por ahora, simulamos algunos códigos de ejemplo
  
  const promos: Record<string, Omit<PromoCode, 'isValid' | 'message'>> = {
    'ALIEN10': { code: 'ALIEN10', discountPercentage: 10, discountAmount: 0 },
    'WELCOME20': { code: 'WELCOME20', discountPercentage: 20, discountAmount: 0, minPurchase: 1000 },
    'FREESHIP': { code: 'FREESHIP', discountPercentage: 0, discountAmount: 200 },
    'MEMBER50': { code: 'MEMBER50', discountPercentage: 50, discountAmount: 0, minPurchase: 2000 }
  };
  
  // Simular una pequeña demora como en una API real
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const promo = promos[code.toUpperCase()];
  
  if (!promo) {
    return {
      code,
      discountPercentage: 0,
      discountAmount: 0,
      isValid: false,
      message: 'Código de promoción inválido'
    };
  }
  
  return {
    ...promo,
    isValid: true,
    message: 'Código aplicado correctamente'
  };
};

// Crear el store con middleware de persistencia
export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      // Estado inicial
      items: [],
      isOpen: false,
      wishlist: [],
      lastAddedItem: null,
      appliedPromo: null,
      currentView: 'cart',
      
      // Métodos de envío disponibles
      shippingMethods: [
        { 
          id: 'standard', 
          name: 'Envío Estándar', 
          description: 'Entrega en 5-7 días hábiles',
          price: 200,
          estimatedDays: '5-7 días'
        },
        { 
          id: 'express', 
          name: 'Envío Express', 
          description: 'Entrega en 2-3 días hábiles',
          price: 350,
          estimatedDays: '2-3 días'
        },
        { 
          id: 'same_day', 
          name: 'Entrega el Mismo Día', 
          description: 'Solo CDMX - Antes de las 8PM',
          price: 500,
          estimatedDays: 'Hoy mismo'
        }
      ],
      
      // Información de checkout inicial
      checkoutInfo: {
        stage: 'cart',
        contactInfo: {
          email: '',
          firstName: '',
          lastName: '',
          phone: ''
        },
        shippingAddress: {
          address1: '',
          city: '',
          state: '',
          zipCode: '',
          country: 'México'
        },
        billingAddress: {
          sameAsShipping: true,
          country: 'México'
        },
        shippingMethod: 'standard',
        paymentMethod: 'credit_card'
      },
      
      // Resumen inicial (vacío)
      summary: {
        subtotal: 0,
        shippingCost: 0,
        discount: 0,
        tax: 0,
        total: 0
      },
      
      // Métodos para manipular ítems
      addItem: (product: Product, quantity = 1) => 
        set((state) => {
          const existingItem = state.items.find(item => item.product.id === product.id);
          
          const newItems = existingItem
            ? state.items.map(item => 
                item.product.id === product.id 
                  ? { ...item, quantity: item.quantity + quantity }
                  : item
              )
            : [...state.items, { product, quantity }];
            
          return {
            items: newItems,
            lastAddedItem: product.id
          };
        }),
        
      removeItem: (productId: number) => 
        set((state) => ({
          items: state.items.filter(item => item.product.id !== productId)
        })),
        
      updateQuantity: (productId: number, quantity: number) => 
        set((state) => ({
          items: state.items.map(item => 
            item.product.id === productId 
              ? { ...item, quantity }
              : item
          )
        })),
        
      clearCart: () => set({ items: [] }),
      
      // Métodos de UI
      toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),
      closeCart: () => set({ isOpen: false }),
      openCart: () => set({ isOpen: true, currentView: 'cart' }),
      
      setCartView: (view) => set({ currentView: view }),
      
      // Métodos de lista de deseos
      addToWishlist: (productId) => 
        set((state) => {
          if (state.wishlist.includes(productId)) return state;
          return { wishlist: [...state.wishlist, productId] };
        }),
        
      removeFromWishlist: (productId) => 
        set((state) => ({
          wishlist: state.wishlist.filter(id => id !== productId)
        })),
        
      moveToCart: (productId, quantity = 1) => {
        const state = get();
        const productInWishlist = state.wishlist.includes(productId);
        
        if (productInWishlist) {
          // Aquí normalmente haríamos una llamada para obtener el producto completo
          // Por ahora simulamos que tenemos el producto
          
          // Simular producto ficticio con el ID (en una app real, obtendríamos el producto real)
          const mockProduct: Product = {
            id: productId,
            name: `Producto #${productId}`,
            description: 'Descripción del producto',
            price: 1000, // Precio ficticio
            image: 'https://via.placeholder.com/300',
            rating: 4.5,
            reviews: 10
          };
          
          // Añadir al carrito y quitar de la lista de deseos
          state.addItem(mockProduct, quantity);
          state.removeFromWishlist(productId);
        }
      },
      
      // Métodos de checkout
      applyPromoCode: async (code) => {
        const promo = await validatePromoCode(code);
        const state = get();
        
        // Verificar si el código requiere compra mínima
        if (promo.isValid && promo.minPurchase) {
          const subtotal = calculateSubtotal(state.items);
          
          if (subtotal < promo.minPurchase) {
            set({ 
              appliedPromo: { 
                ...promo, 
                isValid: false, 
                message: `Compra mínima de $${promo.minPurchase} requerida`
              } 
            });
            return false;
          }
        }
        
        set({ appliedPromo: promo });
        
        if (promo.isValid) {
          state.calculateSummary();
          return true;
        }
        
        return false;
      },
      
      removePromoCode: () => {
        set({ appliedPromo: null });
        get().calculateSummary();
      },
      
      calculateSummary: () => {
        const state = get();
        const subtotal = calculateSubtotal(state.items);
        const shippingCost = calculateShipping(
          state.items, 
          state.checkoutInfo.shippingMethod,
          state.shippingMethods
        );
        const discount = calculateDiscount(subtotal, state.appliedPromo);
        const tax = calculateTax(subtotal, discount);
        const total = subtotal - discount + shippingCost + tax;
        
        set({ 
          summary: {
            subtotal,
            shippingCost,
            discount,
            tax,
            total
          }
        });
      },
      
      setCheckoutStage: (stage) => 
        set(state => ({
          checkoutInfo: { ...state.checkoutInfo, stage }
        })),
        
      updateCheckoutInfo: (info) => 
        set(state => ({
          checkoutInfo: { ...state.checkoutInfo, ...info }
        })),
        
      selectShippingMethod: (methodId) => {
        set(state => ({
          checkoutInfo: { ...state.checkoutInfo, shippingMethod: methodId }
        }));
        get().calculateSummary();
      },
      
      processOrder: async () => {
        // Simular procesamiento de pedido
        const state = get();
        
        // Validar que hay items en el carrito
        if (state.items.length === 0) {
          return {
            success: false,
            message: 'No hay productos en el carrito'
          };
        }
        
        // Validar información de contacto y envío
        const { contactInfo, shippingAddress } = state.checkoutInfo;
        const requiredFields = [
          contactInfo.email, 
          contactInfo.firstName, 
          contactInfo.lastName,
          shippingAddress.address1,
          shippingAddress.city,
          shippingAddress.state,
          shippingAddress.zipCode
        ];
        
        if (requiredFields.some(field => !field)) {
          return {
            success: false,
            message: 'Por favor complete toda la información requerida'
          };
        }
        
        // Simular una demora en el procesamiento
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Generar un ID de pedido ficticio
        const orderId = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        
        // Limpiar el carrito después de un pedido exitoso
        set({ 
          items: [],
          appliedPromo: null,
          checkoutInfo: {
            ...state.checkoutInfo,
            stage: 'confirmation'
          }
        });
        
        return {
          success: true,
          orderId,
          message: 'Pedido procesado con éxito'
        };
      }
    }),
    {
      name: 'alien-mx-cart', // nombre para localStorage
      partialize: (state) => ({
        items: state.items,
        wishlist: state.wishlist,
        appliedPromo: state.appliedPromo,
        checkoutInfo: state.checkoutInfo,
      }),
    }
  )
);;
